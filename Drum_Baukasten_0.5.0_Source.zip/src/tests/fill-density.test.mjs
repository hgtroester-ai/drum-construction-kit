import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=fs.readFileSync('src/ui.ts','utf8');
test('Fill generator supports mixed sixteenth density with genre-specific fast-hand bias',()=>{
 assert.match(source,/const fastBias=family==='punk'\?68:family==='rock'\?52:family==='alternative'\?48/);
 assert.match(source,/const sparse=family==='alternative'\?densityRoll<28/);
 assert.match(source,/if\(fast\)/);
 assert.match(source,/const candidates=family==='punk'/);
});
test('Punk, Rock and Alternative fills combine sparse and busy variants with faster instrument movement',()=>{
 assert.match(source,/const fastHands=fast&&\(family==='punk'\|\|family==='rock'\|\|family==='alternative'\)/);
 assert.match(source,/movement===2\|\|movement===5\?tomOrder/);
 assert.match(source,/rhythm=\[\.\.\.new Set\(rhythm\)\]\.sort/);
});
test('All generated fills retain the last sixteenth cadence and a full 16-step bar',()=>{
 assert.match(source,/if\(!rhythm\.includes\(15\)\)rhythm\.push\(15\)/);
 assert.match(source,/events\.push\(\{step:15,pitch:endingPitch/);
});
