import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
const toms=[43,47,50];
test('Punk 0.4.4 creates distinct 16- and 32-bar Raw Energy solos with a clear final hit',()=>{
 for(const bars of [16,32]){
  const notes=solo.generateSoloNotes('punk',bars,'fullSolo',82,78,37,'heavyBackbeat');
  assert.ok(notes.length>100,`expected a developed ${bars}-bar solo`);
  assert.ok(notes.some(n=>n.pitch===36),'driving kick');
  assert.ok(notes.some(n=>n.pitch===38),'snare backbeat');
  assert.ok(notes.some(n=>toms.includes(n.pitch)),'tom fills');
  assert.ok(notes.every(n=>n.time>=0&&n.time<bars*4&&n.duration>0&&n.duration<=bars*4-n.time+.0001));
  const last=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(last.length>=4,'last bar must continue the groove without a break or fill');assert.ok(!last.some(n=>n.pitch===49));
  assert.ok(!notes.some(n=>n.time>=bars*4),'no notes beyond clip boundary');
 }
});
test('Punk solo contains real flam grace notes resolving to accented snare/tom strokes',()=>{
 const notes=solo.generateSoloNotes('punk',16,'fullSolo',82,80,37);
 const grace=notes.filter(n=>[38,43].includes(n.pitch)&&notes.some(m=>m.pitch===n.pitch&&m.time>n.time&&m.time-n.time<.08&&m.velocity>n.velocity+10));
 assert.ok(grace.length>=2,'expected flam grace notes');
});
test('Punk stop-and-go break creates intentional space in the second phrase',()=>{
 const notes=solo.generateSoloNotes('punk',16,'fullSolo',80,70,23);
 const bar=notes.filter(n=>n.time>=28&&n.time<32);
 assert.ok(bar.length<=8,'bar 8 should be a sparse stop-and-go break');
});
test('Punk solo is deterministic by seed and complexity/profile alter its phrasing',()=>{
 const a=solo.generateSoloNotes('punk',16,'fullSolo',78,72,11,'heavyBackbeat');
 const b=solo.generateSoloNotes('punk',16,'fullSolo',78,72,11,'heavyBackbeat');
 const c=solo.generateSoloNotes('punk',16,'fullSolo',78,72,12,'heavyBackbeat');
 const d=solo.generateSoloNotes('punk',16,'fullSolo',78,35,11,'straightEighths');
 assert.deepEqual(a,b);
 assert.notDeepEqual(a,c);
 assert.notDeepEqual(a,d);
});
