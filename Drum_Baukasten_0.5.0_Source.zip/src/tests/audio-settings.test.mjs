import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { readPreviewVolume, writePreviewVolume, DEFAULT_PREVIEW_VOLUME } from '../dist/modules/audioSettings.js';

 test('native settings storage restores the last Preview Volume across dialog sessions', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dck-audio-settings-'));
  try {
    assert.equal(readPreviewVolume(directory), DEFAULT_PREVIEW_VOLUME);
    writePreviewVolume(directory, 20);
    assert.equal(readPreviewVolume(directory), 20);
    writePreviewVolume(directory, 43);
    assert.equal(readPreviewVolume(directory), 43);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('native settings storage validates bounds and safely falls back for corrupt files', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dck-audio-settings-'));
  try {
    assert.throws(() => writePreviewVolume(directory, 101));
    fs.writeFileSync(path.join(directory, 'audio-settings.json'), '{broken', 'utf8');
    assert.equal(readPreviewVolume(directory), DEFAULT_PREVIEW_VOLUME);
    writePreviewVolume(directory, 0);
    assert.equal(readPreviewVolume(directory), 0);
    writePreviewVolume(directory, 100);
    assert.equal(readPreviewVolume(directory), 100);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('dialog passes Preview Volume to native storage on both Create and Cancel', () => {
  const ui = fs.readFileSync('src/ui.ts', 'utf8');
  const extension = fs.readFileSync('src/extension.ts', 'utf8');
  assert.match(ui, /previewVolume:Number\(\$\('previewVolume'\)\.value\)/);
  assert.match(ui, /type:'cancel',previewVolume:Number\(\$\('previewVolume'\)\.value\)/);
  assert.match(ui, /audioMaster\.gain\.setTargetAtTime\(v\/100,audioContext\.currentTime,\.02\)/);
  assert.doesNotMatch(ui, /localStorage/);
  assert.match(extension, /readSettings\(storageDirectory\)/);
  assert.match(extension, /writeSettings\(storageDirectory,msg\.previewVolume,msg\.uiState\)/);
  assert.match(extension, /settingsSaveError/);
});
