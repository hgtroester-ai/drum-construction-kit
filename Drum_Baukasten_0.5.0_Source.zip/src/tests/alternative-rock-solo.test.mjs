import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
const toms=[43,47,50];
test('Alternative Rock 16- and 32-bar solos use broken motifs, dynamic drops and composed phrase fills',()=>{
 for(const bars of [16,32]){
  const notes=solo.generateSoloNotes('alternativeRock',bars,'fullSolo',78,72,37);
  assert.ok(notes.length>100);
  assert.ok(notes.some(n=>n.pitch===36),'kick motif');
  assert.ok(notes.some(n=>n.pitch===38),'snare motif');
  assert.ok(notes.some(n=>toms.includes(n.pitch)),'tom responses');
  assert.ok(notes.some(n=>n.pitch===37),'rimshot / dynamic drop');
  assert.ok(notes.every(n=>n.time>=0&&n.time<bars*4));
  const last=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(last.length>=4,'last bar must continue the groove, not collapse to one hit');
  assert.ok(!last.some(n=>n.pitch===49),'Complete Solo must not force a final crash');
 }
});
test('Alternative Rock solo contains real grace-note flams before accented snare or tom hits',()=>{
 const notes=solo.generateSoloNotes('alternativeRock',16,'fullSolo',80,75,37);
 const grace=notes.filter(n=>[38,43].includes(n.pitch)&&notes.some(m=>m.pitch===n.pitch&&m.time>n.time&&m.time-n.time<.08&&m.velocity>n.velocity+10));
 assert.ok(grace.length>=2,'expected flam grace notes');
 assert.ok(grace.some(g=>notes.some(n=>n.pitch===g.pitch&&n.time>g.time&&n.time-g.time<.08&&n.velocity>g.velocity+10)), 'grace notes should resolve into accented main strokes');
});
test('Alternative Rock seeded phrase variations are repeatable and distinct',()=>{
 const a=solo.generateSoloNotes('alternativeRock',16,'fullSolo',75,65,11);
 const b=solo.generateSoloNotes('alternativeRock',16,'fullSolo',75,65,11);
 const c=solo.generateSoloNotes('alternativeRock',16,'fullSolo',75,65,12);
 assert.deepEqual(a,b);
 assert.notDeepEqual(a,c);
});
