import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const ui = await import(pathToFileURL(path.resolve('dist/modules/ui.js')).href);
test('Audio Preview UI and MP3 assets are embedded',()=>{
 const html=ui.buildUiHtml([],{});
 assert.match(html,/AUDIO PREVIEW/);
 assert.match(html,/Preview Arrangement/);
 assert.match(html,/Stop Preview/);
 assert.match(html,/decodeAudioData/);
 for(const key of ['crash','ride','kick','snare','rim','lowtom','midtom','hitom','closedhat','openhat']) assert.ok(html.includes('"'+key+'":"'),`missing MP3 asset ${key}`);
});
test('Audio preview uses the same serialized arrangement notes as MIDI export',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 assert.match(source,/const built=serializeNotes\(arr\)/);
 assert.match(source,/function post\(\).*serializeNotes\(lastArrangement\)/);
 assert.match(source,/function audioStop\(\)/);
});
