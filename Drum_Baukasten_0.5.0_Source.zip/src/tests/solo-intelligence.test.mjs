import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
const genres=['classicRock','bluesRock','alternativeRock','punk','reggae','ska','funk','hipHop'];
test('Solo Intelligence adds technical rudiment articulation across all eight genres',()=>{
 for(const genre of genres){
  const notes=solo.generateSoloNotes(genre,16,'fullSolo',78,82,37);
  assert.ok(notes.length>0,genre);
  assert.ok(notes.some(n=>Math.abs(n.time*8-Math.round(n.time*8))<1e-7),`${genre} should contain a 32nd-note/grace-note articulation`);
  assert.ok(notes.some(n=>[38,43,47,50].includes(n.pitch)),`${genre} should use snare/tom rudiment voices`);
 }
});
test('Solo Intelligence changes phrase material with seed and technical complexity',()=>{
 const low=solo.generateSoloNotes('funk',16,'fullSolo',70,25,11);
 const high=solo.generateSoloNotes('funk',16,'fullSolo',70,90,11);
 const alternate=solo.generateSoloNotes('funk',16,'fullSolo',70,90,29);
 assert.notDeepEqual(high,low,'higher complexity should change technical articulation');
 assert.notDeepEqual(high,alternate,'different seeds should produce different phrase choices');
});
test('Solo Intelligence retains the opening motif as a transformed later reprise',()=>{
 const notes=solo.generateSoloNotes('alternativeRock',16,'fullSolo',75,75,23);
 const opening=notes.filter(n=>n.time<4&&[36,38,43,47,50].includes(n.pitch));
 const reprise=notes.filter(n=>n.time>=32&&n.time<40&&[36,38,43,47,50].includes(n.pitch));
 assert.ok(opening.length>=3);
 assert.ok(reprise.length>=3);
 assert.notDeepEqual(reprise.map(n=>[n.pitch,n.time%4]),opening.map(n=>[n.pitch,n.time%4]));
});
test('Solo Intelligence keeps every generated note inside the requested clip and preserves Outro',()=>{
 for(const genre of genres)for(const bars of [4,8,16,32]){
  const notes=solo.generateSoloNotes(genre,bars,'fullSolo',80,85,17);
  assert.ok(notes.every(n=>n.time>=0&&n.time<bars*4&&n.duration>0&&n.duration<=bars*4-n.time+.0001));
 }
 const outro=solo.generateSoloNotes('classicRock',8,'soloOutro');
 const ending=outro.filter(n=>n.time===28);
 assert.ok(ending.some(n=>n.pitch===36&&n.velocity===127&&n.duration===4));
 assert.ok(ending.some(n=>n.pitch===49&&n.velocity===127&&n.duration===4));
});

test('Classic Rock 0.4.1 states, develops and resolves one recurring hybrid motif',()=>{
 const notes=solo.generateSoloNotes('classicRock',16,'fullSolo',78,82,37);
 const inBar=(bar)=>notes.filter(n=>n.time>=bar*4&&n.time<(bar+1)*4);
 const has=(bar,step,pitch)=>inBar(bar).some(n=>Math.abs(n.time-(bar*4+step*.25))<1e-7&&n.pitch===pitch);
 assert.ok(has(0,0,49)&&has(0,0,36),'opening statement has crash and kick');
 assert.ok(has(0,4,38)&&has(0,12,38),'opening motif places snare on beats 2 and 4');
 assert.ok(inBar(1).some(n=>[47,43,50].includes(n.pitch)),'second bar answers with toms');
 assert.ok(inBar(4).some(n=>n.pitch===36)&&inBar(4).some(n=>n.pitch===38),'second four-bar phrase recalls the kick/snare identity');
 assert.ok(inBar(10).filter(n=>[38,43,47,50].includes(n.pitch)).length>4,'third phrase develops into a denser rudimental exchange');
 assert.ok(inBar(15).length>=4&&!inBar(15).some(n=>n.pitch===49),'Complete Solo continues through the final bar without a forced crash');
 assert.ok(!notes.some(n=>n.time>=64),'no notes beyond the clip boundary');
});

test('Classic Rock 0.4.1 preserves the motif while seed and complexity shape details',()=>{
 const base=solo.generateSoloNotes('classicRock',16,'fullSolo',78,82,37);
 const alternate=solo.generateSoloNotes('classicRock',16,'fullSolo',78,82,51);
 const low=solo.generateSoloNotes('classicRock',16,'fullSolo',78,20,37);
 const runCount=xs=>xs.filter(n=>n.time>=40&&n.time<48&&[38,43,47,50].includes(n.pitch)).length;
 assert.notDeepEqual(base,alternate,'seed changes small phrase details');
 assert.ok(runCount(base)>runCount(low),'higher complexity creates denser controlled runs');
 const opening=base.filter(n=>n.time<4&&[36,38,43,47,50].includes(n.pitch));
 const reprise=base.filter(n=>n.time>=16&&n.time<20&&[36,38,43,47,50].includes(n.pitch));
 assert.ok(opening.length>=3&&reprise.length>=3,'opening identity returns in transformed orchestration');
});

test('Classic Rock Solo complexity control changes the sixteenth-run density',()=>{
 const low=solo.generateSoloNotes('classicRock',8,'fullSolo',78,20,37);
 const high=solo.generateSoloNotes('classicRock',8,'fullSolo',78,90,37);
 const runCount=(xs)=>xs.filter(n=>n.time>=12&&n.time<16&&[38,43,47,50].includes(n.pitch)).length;
 assert.ok(runCount(high)>runCount(low),'higher technical complexity should create denser sixteenth-note runs');
});
