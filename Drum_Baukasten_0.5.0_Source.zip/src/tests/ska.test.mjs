import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source=fs.readFileSync('src/ui.ts','utf8');
test('Ska has dedicated and distinct Two Tone and Offbeat groove engines',()=>{
 assert.match(source,/function applySkaPersonality\(p,drummer,bar,section,influence\)/);
 assert.match(source,/p\.kick=unique\(\[0,4,8,12/);
 assert.match(source,/p\.hat=\[0,2,4,6,8,10,12,14\]/);
 assert.match(source,/p\.openHat=bar%2===0\?\[6,14\]:\[2,10\]/);
 assert.match(source,/p\.kick=\[0,8\];p\.snare=\[4,12\];p\.rim=\[\];p\.hat=\[0,4,8,12\];p\.openHat=\[2,6,10,14\]/);
 assert.match(source,/applySkaPersonality\(p,localDrummer,bar,s,arr\.styleInfluence\|\|0\)/);
});
test('Ska fills are energetic, varied and include snare, kick and tom movement',()=>{
 assert.match(source,/Full-Bar Fill Intelligence/);
 assert.match(source,/const g=String\(genre\)\.toLowerCase\(\)/);
 assert.match(source,/function generateIntelligentFill/);
 assert.match(source,/family==='punk'/);
});
test('Ska cymbal engine preserves offbeat character without ride wash',()=>{
 assert.match(source,/else if\(isSka\)\{p\.ride=\[\]/);
 assert.match(source,/Ska keeps its characteristic offbeat hats/);
});
