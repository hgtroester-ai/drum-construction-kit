import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
test('Ska Complete Solo keeps its offbeat lift and full final bar across 8/16/32 bars',()=>{
 for(const bars of [8,16,32]){
  const notes=solo.generateSoloNotes('ska',bars,'fullSolo',78,72,31);
  const final=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(final.length>=8,`last bar too sparse for ${bars} bars`);
  assert.ok(final.some(n=>[42,46].includes(n.pitch)&&[2,6,10,14].includes(Math.round((n.time%4)*4))),'offbeat hi-hat must continue');
  assert.ok(final.some(n=>n.pitch===36),'kick must continue');
  assert.ok(final.some(n=>n.pitch===38),'snare must continue');
  assert.ok(!final.some(n=>n.pitch===49),'Complete Solo must not force an outro crash');
 }
});
test('Ska solo uses offbeat timekeeping plus developing tom and snare phrases',()=>{
 const notes=solo.generateSoloNotes('ska',16,'fullSolo',80,80,17);
 assert.ok(notes.some(n=>n.pitch===47||n.pitch===50||n.pitch===43));
 assert.ok(notes.some(n=>n.pitch===38&&n.velocity>75));
 assert.ok(notes.some(n=>[42,46].includes(n.pitch)&&[2,6,10,14].includes(Math.round((n.time%4)*4))));
});
test('Ska solo varies deterministically with seed',()=>{
 const a=solo.generateSoloNotes('ska',16,'fullSolo',75,70,11);
 const b=solo.generateSoloNotes('ska',16,'fullSolo',75,70,11);
 const c=solo.generateSoloNotes('ska',16,'fullSolo',75,70,12);
 assert.deepEqual(a,b);assert.notDeepEqual(a,c);
});
