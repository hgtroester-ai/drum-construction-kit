import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync('src/ui.ts','utf8');
test('Classic Rock has dedicated processing for the three requested profiles',()=>{
 assert.match(ui,/function applyClassicRockPersonality/);
 for(const profile of ['straightEighths','heavyBackbeat','dynamicToms']) assert.ok(ui.includes("drummer==='"+profile+"'"));
 assert.match(ui,/applyClassicRockPersonality\(p,localDrummer,bar,s/);
});
test('Classic Rock Dynamic Toms uses a distinct tom-led fill phrase',()=>{
 assert.match(ui,/const tomOrder=drummer==='dynamicToms'\?\[50,47,43\]/);
 assert.match(ui,/drummer==='rollingToms'\|\|drummer==='dynamicToms'/);
});
test('Classic Rock Straight Eighths and Heavy Backbeat have distinct core patterns',()=>{
 assert.match(ui,/steady eighth-note hat engine/);
 assert.match(ui,/stronger quarter-note kick anchors/);
});
