import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync('src/ui.ts','utf8');
test('Punk tempo defaults to 145 BPM, matching Ska',()=>{assert.match(ui,/punk:145,reggae:78,ska:145/);});
test('Punk has dedicated Straight Eighths, Heavy Backbeat and Precision Fills engines',()=>{assert.match(ui,/function applyPunkPersonality\(p,drummer,bar,section,influence\)/);for(const profile of ['straightEighths','heavyBackbeat','precisionFills'])assert.ok(ui.includes("drummer==='"+profile+"'"));assert.match(ui,/applyPunkPersonality\(p,localDrummer,bar,s/);});
test('Punk uses the shared full-bar fill engine while retaining precision profile voicing',()=>{assert.match(ui,/Full-Bar Fill Intelligence/);assert.match(ui,/const fillVel=/);assert.match(ui,/localDrummer==='precisionFills'/);});
