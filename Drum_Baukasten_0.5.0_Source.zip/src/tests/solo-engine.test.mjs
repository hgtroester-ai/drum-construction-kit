import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
const genres=['classicRock','bluesRock','alternativeRock','punk','reggae','ska','funk','hipHop'];
const types=['fullSolo','drumBreak','tradingFours','soloOutro'];
test('Solo Engine generates valid, bounded notes for every genre, type and supported length',()=>{
 for(const genre of genres)for(const type of types)for(const bars of [1,2,4,8,16,32]){
  const notes=solo.generateSoloNotes(genre,bars,type,75,65,19);
  assert.ok(notes.length>0,`${genre}/${type}/${bars}`);
  for(const n of notes){assert.ok(n.pitch>=35&&n.pitch<=51);assert.ok(n.time>=0&&n.time<bars*4);assert.ok(n.duration>0&&n.duration<=bars*4-n.time+.0001);assert.ok(n.velocity>=1&&n.velocity<=127);}
 }
});
test('Solo Outro ends with a sustained kick and crash at the final downbeat',()=>{
 const n=solo.generateSoloNotes('classicRock',8,'soloOutro');
 const last=n.filter(x=>x.time===28);
 assert.ok(last.some(x=>x.pitch===36&&x.velocity===127&&x.duration===4));
 assert.ok(last.some(x=>x.pitch===49&&x.velocity===127&&x.duration===4));
});
test('genre-specific solo patterns are not identical',()=>{
 const signatures=genres.map(g=>JSON.stringify(solo.generateSoloNotes(g,8,'fullSolo',75,65,19)));
 assert.equal(new Set(signatures).size,genres.length);
});
test('Trading Fours has alternating four-bar timekeeping phrases',()=>{
 const notes=solo.generateSoloNotes('bluesRock',8,'tradingFours');
 const first=notes.filter(n=>n.time<16),second=notes.filter(n=>n.time>=16);
 assert.ok(first.length>0&&second.length>0);
 assert.ok(first.some(n=>[43,47,50,38].includes(n.pitch)));
 assert.ok(second.every(n=>[36,38,42,46,49,51,37].includes(n.pitch)));
});
test('Solo personalities map the available genres to distinct musical approaches',()=>{
 assert.equal(solo.getSoloPersonality('classicRock'),'rockHardRock');
 assert.equal(solo.getSoloPersonality('punk'),'punkDrive');
 assert.equal(solo.getSoloPersonality('alternativeRock'),'alternativeRock');
 assert.equal(solo.getSoloPersonality('bluesRock'),'bluesRock');
 assert.equal(solo.getSoloPersonality('funk'),'funkSoul');
 assert.equal(solo.getSoloPersonality('hipHop'),'hipHopBoomBap');
 assert.equal(solo.getSoloPersonality('reggae'),'reggaeSka');
 assert.equal(solo.getSoloPersonality('ska'),'reggaeSka');
});
test('Funk solo includes low-velocity ghost-note articulation',()=>{
 const notes=solo.generateSoloNotes('funk',4,'fullSolo',75,70,21);
 assert.ok(notes.some(n=>n.pitch===38&&n.velocity<65));
});
test('Blues Rock solo uses shuffle ride timekeeping and bluesy tom phrases',()=>{
 const notes=solo.generateSoloNotes('bluesRock',4,'fullSolo',75,70,21);
 assert.ok(notes.some(n=>n.pitch===51));
 assert.ok(notes.some(n=>[43,47,50].includes(n.pitch)));
});
test('Alternative Rock Complete Solo resolves without a forced final crash',()=>{
 const bars=8,notes=solo.generateSoloNotes('alternativeRock',bars,'fullSolo',75,65,19);
 const ending=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
 assert.ok(ending.length>=4,'Complete Solo must continue the groove in the last bar');
 assert.ok(!ending.some(n=>n.pitch===49));
 assert.ok(notes.every(n=>n.time<bars*4));
});
test('Solo Outro retains its exact sustained final kick and crash without an added cadence',()=>{
 const bars=8,notes=solo.generateSoloNotes('classicRock',bars,'soloOutro');
 const last=notes.filter(x=>x.time===28);
 assert.equal(last.filter(x=>x.pitch===36&&x.velocity===127&&x.duration===4).length,1);
 assert.equal(last.filter(x=>x.pitch===49&&x.velocity===127&&x.duration===4).length,1);
 assert.equal(notes.filter(x=>x.time===31.75).length,0);
});
test('Dramaturgy creates a stronger middle/peak than opening without forcing monotonic density',()=>{
 const notes=solo.generateSoloNotes('classicRock',16,'fullSolo',75,65,19);
 const median=(xs)=>{const a=xs.map(x=>x.velocity).sort((a,b)=>a-b);return a[Math.floor(a.length/2)];};
 const opening=notes.filter(n=>n.time<8),peak=notes.filter(n=>n.time>=36&&n.time<48);
 assert.ok(median(peak)>median(opening));
});

 test('Five target genres use distinct solo vocabularies',()=>{
  const targets=['classicRock','bluesRock','funk','punk','alternativeRock'];
  const sig=targets.map(g=>JSON.stringify(solo.generateSoloNotes(g,8,'fullSolo',75,65,31)));
  assert.equal(new Set(sig).size,5);
  const punk=solo.generateSoloNotes('punk',4,'fullSolo',75,65,31);
  assert.ok(punk.filter(n=>n.pitch===36).length>10,'punk should sustain a driving kick pattern');
  const blues=solo.generateSoloNotes('bluesRock',4,'fullSolo',75,65,31);
  assert.ok(blues.some(n=>n.pitch===51),'blues rock should retain ride-led shuffle phrasing');
  const funk=solo.generateSoloNotes('funk',4,'fullSolo',75,65,31);
  assert.ok(funk.some(n=>n.pitch===38&&n.velocity<65),'funk should retain ghost-note articulation');
 });

test('Rock expansion differentiates Classic Rock and Hard Rock voicings by drummer profile',()=>{
 const classic=solo.generateSoloNotes('classicRock',8,'fullSolo',75,65,41,'straightEighths');
 const hard=solo.generateSoloNotes('classicRock',8,'fullSolo',75,65,41,'heavyBackbeat');
 assert.notDeepEqual(classic,hard,'heavy backbeat should have a distinct harder rock vocabulary');
 assert.ok(hard.some(n=>n.pitch===51),'hard-rock profile should use ride timekeeping');
 assert.ok(hard.some(n=>n.pitch===49),'hard-rock profile should use phrase-led crash accents');
});

test('Solo Interaction adds answering tom/snare phrases and recalls the opening motif',()=>{
 const notes=solo.generateSoloNotes('classicRock',8,'fullSolo',75,65,53,'heavyBackbeat');
 const response=notes.filter(n=>n.time>=4&&n.time<8&&[43,47,50].includes(n.pitch));
 const recall=notes.filter(n=>n.time>=16&&n.time<20&&[36,47].includes(n.pitch));
 assert.ok(response.length>=2,'second bar should answer the opening phrase with tom voices');
 assert.ok(recall.length>=2,'bar five should recall the opening motif with variation');
});

test('Solo Interaction leaves short solo types and the exact Solo Outro invariant unchanged',()=>{
 const short=solo.generateSoloNotes('classicRock',2,'fullSolo',75,65,53);
 assert.ok(short.every(n=>n.time<8));
 const outro=solo.generateSoloNotes('classicRock',8,'soloOutro');
 const last=outro.filter(n=>n.time===28);
 assert.ok(last.some(n=>n.pitch===36&&n.velocity===127&&n.duration===4));
 assert.ok(last.some(n=>n.pitch===49&&n.velocity===127&&n.duration===4));
});

test('Solo Type Logic matrix: Complete Solo has no forced final crash in any genre',()=>{
 for(const genre of genres)for(const bars of [4,16,32]){
  const notes=solo.generateSoloNotes(genre,bars,'fullSolo',78,72,37);
  assert.ok(!notes.some(n=>n.pitch===49&&n.time>=(bars-1)*4),`${genre}/${bars} must not end with a forced crash`);
 }
});
test('Solo Type Logic matrix: Solo Outro has one exact sustained kick/crash final downbeat for every genre',()=>{
 for(const genre of genres)for(const bars of [1,4,16,32]){
  const notes=solo.generateSoloNotes(genre,bars,'soloOutro',78,72,37);
  const last=notes.filter(n=>n.time===(bars-1)*4);
  assert.equal(last.filter(n=>n.pitch===36&&n.velocity===127&&n.duration===4).length,1,`${genre}/${bars} kick`);
  assert.equal(last.filter(n=>n.pitch===49&&n.velocity===127&&n.duration===4).length,1,`${genre}/${bars} crash`);
  assert.ok(!notes.some(n=>n.time>(bars-1)*4),`${genre}/${bars} no notes after outro hit`);
 }
});
test('Solo Type Logic matrix: Trading Fours alternates solo and timekeeping every four bars',()=>{
 for(const genre of genres){
  const notes=solo.generateSoloNotes(genre,8,'tradingFours',75,65,19);
  const soloPhrase=notes.filter(n=>n.time<16),timekeeping=notes.filter(n=>n.time>=16);
  assert.ok(soloPhrase.length>0&&timekeeping.length>0,`${genre} has both roles`);
 }
});

test('Complete Solo plays continuously through the final bar across all genres',()=>{
 for(const genre of genres)for(const bars of [4,8,16,32]){
  const notes=solo.generateSoloNotes(genre,bars,'fullSolo',78,72,37);
  const last=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(last.length>=4,`${genre}/${bars}: final bar continues playing`);
  assert.ok(!last.some(n=>n.pitch===49),`${genre}/${bars}: no forced crash`);
 }
});
test('Drum Break and Trading Fours have distinct rhythmic identities',()=>{
 for(const genre of genres){
  const br=solo.generateSoloNotes(genre,8,'drumBreak',78,72,37);
  const tf=solo.generateSoloNotes(genre,8,'tradingFours',78,72,37);
  assert.notDeepEqual(br,tf,`${genre}: Drum Break must differ from Trading Fours`);
  const timekeeping=tf.filter(n=>n.time>=16&&n.time<32);
  assert.ok(timekeeping.length>0,`${genre}: Trading Fours has a return to timekeeping`);
 }
});


test('Hip-Hop Complete Solo has boom-bap backbeat, syncopated kick and ghost snares',()=>{
 const notes=solo.generateSoloNotes('hipHop',16,'fullSolo',78,78,29);
 assert.ok(notes.some(n=>n.pitch===36&&[0,1.5,2.5,3.5].includes(n.time%4)));
 assert.ok(notes.some(n=>n.pitch===38&&n.velocity<65),'ghost snares should be present');
 assert.ok(notes.some(n=>n.pitch===42),'closed hats should establish the pocket');
 const ending=notes.filter(n=>n.time>=60&&n.time<64);
 assert.ok(ending.length>=6,'Complete Solo must continue through the final bar');
 assert.ok(!ending.some(n=>n.pitch===49),'no forced final crash');
});

test('Hip-Hop Complete Solo avoids continuous rock-style tom runs',()=>{
 const notes=solo.generateSoloNotes('hipHop',8,'fullSolo',75,65,31);
 const toms=notes.filter(n=>[43,47,50].includes(n.pitch));
 assert.ok(toms.length<=8,'Hip-Hop solo should use sparse tom punctuation');
});
