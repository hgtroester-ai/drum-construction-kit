import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
const ui = await import(pathToFileURL(path.resolve('dist/modules/ui.js')).href);
test('UI is English, has a cancel button and only creates section clips',()=>{
 const html=ui.buildUiHtml([],{});
 assert.match(html,/Create section clips/);
 assert.match(html,/supported with AI/);
 assert.match(html,/Fill repeat control/);
 assert.match(html,/Section genre/);
 assert.match(html,/Section drummer/);
 assert.match(html,/Broken Beats & Displaced Accents/);
 assert.match(html,/Drum<br>Construction<br>Kit/);
 assert.doesNotMatch(html,/by Dinoel|John — Power|Clyde — Ghost|Ahmir — Deep Pocket/);
 assert.doesNotMatch(html,/Fill interval|Every 12 bars/);
 assert.match(html,/>Cancel</);
 assert.match(html,/Suggested tempo/);
 assert.match(html,/Fill placement is managed automatically by the song-section phrase engine/);
 assert.doesNotMatch(html,/Gesamt-Clip|Full Arrangement|Gesamt-Arrangement|MIDI-Ausgabe/);
});
test('UI implements distinct fill shapes, sparse crashes and a final outro kick',()=>{
 const source=requireSource();
 assert.match(source,/repeatMode==='strict'/);
 assert.match(source,/Avoid repeats/);
 assert.match(source,/Cymbal Intelligence selects sparse, section-aware crash accents/);
 assert.match(source,/One-Bar Outro: one sustained kick and crash together on beat one, then silence/);
 assert.match(source,/add\(\[0\],36,127,4\)/);
 assert.match(source,/add\(\[0\],49,127,4\)/);
 assert.match(source,/const localGenre=s.sectionGenre\|\|arr.genre/);
 assert.match(source,/const localDrummer=s.sectionDrummer\|\|arr.drummerStyle/);
});
function requireSource(){
 // The generated bundle contains the exact source strings used by the UI's fill engine.
 return fs.readFileSync('dist/extension.js','utf8');
}

test('release credit and visible drummer labels are standardized',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/Drum<br>Construction<br>Kit/);assert.match(fs.readFileSync("src/buildInfo.ts","utf8"),/BUILD 0.5.0/);for(const forbidden of ['by Dinoel','John — Power','Clyde — Ghost Notes','Ahmir — Deep Pocket'])assert.ok(!source.includes(forbidden),`unexpected visible label: ${forbidden}`);});

test('brand header uses the requested stacked title and full credit',()=>{
 const html=ui.buildUiHtml([], {});
 assert.match(html,/Drum<br>Construction<br>Kit/);
 assert.match(html,/by HGT<br>supported with AI/);
 assert.match(html,/#brandMark\{width:58px/);
});

test('logo asset is a transparent vector mark with the reference colors',()=>{
 const logo=fs.readFileSync('src/logo.ts','utf8');
 assert.match(logo,/image\/svg\+xml;base64/);
 const decoded=Buffer.from(logo.match(/base64,([^']+)/)[1],'base64').toString('utf8');
 assert.match(decoded,/<svg/);
 assert.match(decoded,/#f12b2f/);
 assert.match(decoded,/#172de8/);
 assert.match(decoded,/#f05a00/);
 assert.match(decoded,/#ffffff/);
});

test('Jazz-Inflected Shuffle has its own shuffle groove processing',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 assert.match(source,/case 'jazzShuffle':add\('kick',\[0,8\]\)/);
 assert.match(source,/add\('ride',\[0,2,4,6,8,10,12,14\]\)/);
 assert.match(source,/localDrummer==='jazzShuffle'.*timing=influence/s);
 assert.match(source,/step%4===2/);
 assert.match(source,/if\(localDrummer==='jazzShuffle'.*ghostVel/s);
 assert.match(source,/by HGT<br>supported with AI/);
});

test('Drummer Intelligence implements profile-aware groove decisions and fills',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 for(const id of ['powerSwing','jazzShuffle','texasShuffle','heavyBackbeat','straightEighths','oneDrop','offbeatSka','ghostNoteFunk','deepPocket','rollingToms','dynamicToms','precisionFills','tightReggae','twoToneSka','linearFunk','brokenBeats']) {
   assert.ok(source.includes("case '"+id+"'"),'missing profile engine case '+id);
 }
 assert.match(source,/section\.type==='Chorus'/);
 assert.match(source,/section\.type==='Bridge'/);
 assert.match(source,/localDrummer==='rollingToms'\|\|localDrummer==='dynamicToms'/);
 assert.match(source,/localDrummer==='precisionFills'/);
 assert.match(source,/localDrummer==='ghostNoteFunk'\|\|localDrummer==='linearFunk'/);
 assert.match(source,/velocityShape/);
 assert.match(source,/localDrummer==='deepPocket'/);
 assert.match(source,/timing=influence/);
});

test('Human Feel adds profile-specific pocket and velocity articulation',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 assert.match(source,/let pocket=0/);
 assert.match(source,/localDrummer==='deepPocket'\|\|localDrummer==='texasShuffle'/);
 assert.match(source,/localDrummer==='ghostNoteFunk'\|\|localDrummer==='linearFunk'/);
 assert.match(source,/backbeatAccent/);
 assert.match(source,/hatAlternation/);
 assert.match(source,/profileDynamics/);
 assert.match(source,/time:Math.max/);
});

test('Arrangement Safety uses English space warnings and no success export dialog',()=>{
 const extension=fs.readFileSync('src/extension.ts','utf8');
 assert.match(extension,/Not Enough Arrangement Space/);
 assert.match(extension,/consecutive empty clip slots/);
 assert.match(extension,/Nothing was created/);
 assert.doesNotMatch(extension,/Export complete/);
 assert.match(extension,/Successful creation closes silently/);
});

test('Song default clearly displays inherited genre and drummer values',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/Inherited: /);assert.match(source,/globalGenreLabel/);assert.match(source,/globalDrummerLabel/);assert.match(source,/renderSections\(\);buildPreview\(\)/);});

test('Drummer Consistency carries profile alternation across section boundaries',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/const absBar=s\.startBar\+bar/);assert.match(source,/applyDrummerStyle\(p,localDrummer,arr\.styleInfluence\|\|0,absBar,s\)/);assert.match(source,/Drummer Consistency: profile alternation follows the absolute song bar/);});


test('Create section clips regression: absolute bar is initialized before groove profile use',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 const block=source.slice(source.indexOf('function serializeNotes(arr)'),source.indexOf('function serializeNotes(arr)')+1800);
 const declaration=block.indexOf('const absBar=s.startBar+bar');
 const usage=block.indexOf('applyDrummerStyle(p,localDrummer,arr.styleInfluence||0,absBar,s)');
 assert.ok(declaration>=0 && usage>declaration,'absBar must be initialized before applying drummer style');
});

test('Section Transitions adds restrained destination-aware pickups without changing the One-Bar Outro',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/Section Transitions: add a restrained, destination-aware pickup/);assert.match(source,/nextSection\.type==='Chorus'/);assert.match(source,/nextSection\.type==='Bridge'/);assert.match(source,/nextSection\.type==='Verse'/);assert.match(source,/nextSection\.type!=='Outro'/);assert.match(source,/One-Bar Outro is never modified/);});

test('Dynamic Development has an independent control and deterministic profile-aware evolution',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/id=\"dynamicDevelopment\"/);assert.match(source,/Dynamic Development: deterministic, song-aware evolution/);assert.match(source,/arr.dynamicDevelopment/);assert.match(source,/dynamicDevelopmentValue/);});

test('Cymbal Intelligence has an independent control and genre/profile-aware cymbal engine',()=>{const source=fs.readFileSync('src/ui.ts','utf8');const html=ui.buildUiHtml([],{});assert.match(html,/id="cymbalIntelligence"/);assert.match(html,/Cymbal intelligence/);assert.match(source,/applyCymbalIntelligence\(p,/);assert.match(source,/arr\.cymbalIntelligence\?\?60/);assert.match(source,/const isReggae=/);assert.match(source,/const isSka=/);assert.match(source,/const isJazz=/);assert.match(source,/const isFunk=/);assert.match(source,/ride replaces the closed-hat hit/);assert.match(source,/Cymbal Intelligence selects sparse, section-aware crash accents/);assert.match(source,/cymbalIntelligence:lastArrangement\.cymbalIntelligence/);});
test('Cymbal Intelligence preserves the fixed One-Bar Outro before cymbal processing',()=>{const source=fs.readFileSync('src/ui.ts','utf8');const block=source.slice(source.indexOf('function serializeNotes(arr)'),source.indexOf('function serializeNotes(arr)')+10000);const outro=block.indexOf("if(s.type==='Outro'&&bar===s.bars-1)");const cymbal=block.indexOf('applyCymbalIntelligence(p,');const firstCymbalWrite=block.indexOf('add(p.hat,42');assert.ok(outro>=0&&cymbal>=0&&firstCymbalWrite>outro,'Outro guard must occur before any cymbal MIDI notes are written');assert.match(source,/add\(\[0\],36,127,4\)/);assert.match(source,/add\(\[0\],49,127,4\)/);});

test('Groove Variation is an independent deterministic core-groove control',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/id=\"grooveVariation\"/);assert.match(source,/function applyGrooveVariation/);assert.match(source,/applyGrooveVariation\(p,arr\.grooveVariation/);assert.match(source,/Groove Variation: deterministic bar-to-bar micro-edits/);assert.match(source,/grooveVariation:lastArrangement\.grooveVariation/);});

test('Refresh arrangement only assigns variation seeds; fill placement is phrase-managed',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/function generate\(\)\{sections\.forEach\(\(s,i\)=>\{s\.variant=i;\}\)/);assert.match(source,/Phrase Fill Schedule 0\.3\.18/);assert.doesNotMatch(source,/fillDefault|data-prop=\"fillEvery\"|Fill interval/);assert.match(source,/Use Create section clips to write the MIDI clips into Live/);});

test('Funk personalities have separate groove grammars, variation and fills',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/function applyFunkPersonality/);assert.match(source,/drummer==='deepPocket'/);assert.match(source,/drummer==='ghostNoteFunk'/);assert.match(source,/drummer==='linearFunk'/);assert.match(source,/applyFunkPersonality\(p,localDrummer,bar,s,arr\.styleInfluence\|\|0\)/);assert.match(source,/if\(drummer==='deepPocket'\).*if\(drummer==='ghostNoteFunk'\).*if\(drummer==='linearFunk'\)/s);assert.match(source,/localDrummer==='ghostNoteFunk'&&isSnare&&isGhostStep\?-27/);});

test('Blues Rock personalities have dedicated groove, variation, velocity and fill engines',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/function applyBluesRockPersonality/);assert.match(source,/applyBluesRockPersonality\(p,localDrummer,bar,s,arr\.styleInfluence\|\|0\)/);assert.match(source,/genre==='bluesRock'&&drummer==='texasShuffle'/);assert.match(source,/genre==='bluesRock'&&drummer==='heavyBackbeat'/);assert.match(source,/genre==='bluesRock'&&drummer==='powerSwing'/);assert.match(source,/localGenre==='bluesRock'&&localDrummer==='texasShuffle'/);});

test('Blues Rock Power & Swing initializes the optional lowTom lane before using it',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/Normalize optional drum lanes/);assert.match(source,/for\(const lane of \['kick','snare','rim','hat','openHat','crash','ride','hiTom','midTom','lowTom'\]\)if\(!Array\.isArray\(p\[lane\]\)\)p\[lane\]=\[\]/);assert.match(source,/p\.lowTom=unique\(\[\.\.\.p\.lowTom,14\]\)/);});
test('Create section clips reports serialization preparation errors instead of failing silently',()=>{const source=fs.readFileSync('src/ui.ts','utf8');assert.match(source,/function post\(\)\{try\{/);assert.match(source,/Clip creation preparation failed:/);assert.match(source,/Sending '\+sectionsOut\.length\+' section clips to Ableton Live/);});

test('Preview Volume is injected from native settings before the dialog opens',()=>{
 const html=ui.buildUiHtml([],{previewVolume:20});
 assert.match(html,/<span id="previewVolumeValue">20%<\/span>/);
 assert.match(html,/<input id="previewVolume" type="range" min="0" max="100" value="20" step="1">/);
 const fallback=ui.buildUiHtml([],{previewVolume:999});
 assert.match(fallback,/<span id="previewVolumeValue">70%<\/span>/);
});

test('Solo Engine has its own button, solo types, length and dynamics controls',()=>{
 const html=ui.buildUiHtml([] ,{});
 assert.match(html,/DRUM SOLO ENGINE/);
 assert.match(html,/Create Drum Solo Clip/);
 assert.match(html,/Full Solo/);
 assert.match(html,/Trading Fours/);
 assert.match(html,/soloBars/);
 assert.match(html,/soloIntensity/);
 assert.match(html,/soloComplexity/);
 assert.match(html,/BUILD 0\.5\.0/);
 assert.match(html,/Complete Solo: a continuous genre-aware solo/i);
});

test('Audio Preview is in the left sidebar and main sections are renumbered',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 const sidebar=source.indexOf('id="sidebarAudioPreview"');
 const genreList=source.indexOf('id="genreList"');
 const main=source.indexOf('<main id="main">');
 assert.ok(sidebar>genreList && sidebar<main,'Audio Preview must be placed in the left sidebar');
 assert.ok(source.includes('<h2>AUDIO PREVIEW</h2>'));
 assert.ok(source.includes('<h2>4 · CREATE MIDI CLIPS IN ABLETON LIVE</h2>'));
 assert.ok(source.includes('<h2>5 · DRUM SOLO ENGINE</h2>'));
 assert.ok(!source.includes('<h2>6 · DRUM SOLO ENGINE</h2>'));
});
