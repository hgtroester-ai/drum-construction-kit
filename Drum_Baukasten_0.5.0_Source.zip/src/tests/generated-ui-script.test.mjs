import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { buildUiHtml } from '../dist/modules/ui.js';

test('generated UI inline script parses and renders all genre choices', () => {
  const html = buildUiHtml([{ index: 0, name: 'MIDI', slots: [{ index: 0, occupied: false }] }], {}, {});
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  assert.equal(scripts.length, 1, 'one inline application script must be present');
  assert.doesNotThrow(() => new vm.Script(scripts[0][1]), 'inline application script must be syntactically valid');
  assert.match(scripts[0][1], /function renderGenres\(\)/);
  assert.match(scripts[0][1], /renderGenres\(\);renderSections\(\);/);
  assert.match(html, /SELECT GENRE/);
});
