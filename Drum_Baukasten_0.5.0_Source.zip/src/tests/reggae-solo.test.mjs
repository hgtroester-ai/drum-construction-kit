import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
const toms=[43,47,50];
test('Reggae Complete Solo develops 16- and 32-bar phrases without forcing a crash outro',()=>{
 for(const bars of [16,32]){
  const notes=solo.generateSoloNotes('reggae',bars,'fullSolo',82,78,37,'oneDrop');
  assert.ok(notes.length>90,`expected a developed ${bars}-bar solo`);
  assert.ok(notes.some(n=>n.pitch===36),'One Drop kick');
  assert.ok(notes.some(n=>n.pitch===37),'dry rimshot pulse');
  assert.ok(notes.some(n=>toms.includes(n.pitch)),'tom responses');
  assert.ok(notes.every(n=>n.time>=0&&n.time<bars*4&&n.duration>0&&n.duration<=bars*4-n.time+.0001));
  const last=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(last.length>=4,'last bar must continue the groove without a break or fill');assert.ok(!last.some(n=>n.pitch===49));
  assert.ok(!notes.some(n=>n.time>=bars*4),'no notes beyond clip boundary');
 }
});
test('Reggae solo profiles produce different rhythmic identities',()=>{
 const one=solo.generateSoloNotes('reggae',16,'fullSolo',80,72,19,'oneDrop');
 const rocker=solo.generateSoloNotes('reggae',16,'fullSolo',80,72,19,'rockers');
 const stepper=solo.generateSoloNotes('reggae',16,'fullSolo',80,72,19,'steppers');
 assert.notDeepEqual(one,rocker);assert.notDeepEqual(rocker,stepper);
 assert.ok(stepper.filter(n=>n.pitch===36).length>rocker.filter(n=>n.pitch===36).length);
});
test('Reggae solo is deterministic and seed changes fills',()=>{
 const a=solo.generateSoloNotes('reggae',16,'fullSolo',78,75,11,'oneDrop');
 const b=solo.generateSoloNotes('reggae',16,'fullSolo',78,75,11,'oneDrop');
 const c=solo.generateSoloNotes('reggae',16,'fullSolo',78,75,12,'oneDrop');
 assert.deepEqual(a,b);assert.notDeepEqual(a,c);
});
