import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync('src/ui.ts','utf8');
test('Reggae profiles have separate core groove identities',()=>{
 assert.match(ui,/function applyReggaePersonality\(p,drummer,bar,influence\)/);
 assert.match(ui,/if\(drummer==='oneDrop'\)\{p\.kick=\[8\];p\.snare=\[\];p\.rim=\[8\]/);
 assert.match(ui,/else if\(drummer==='tightReggae'\)\{p\.kick=\[0,8\];p\.snare=\[\];p\.rim=\[8\]/);
 assert.match(ui,/applyReggaePersonality\(p,localDrummer,bar,arr\.styleInfluence\|\|0\)/);
});
test('Reggae remains free of automatic crash and ride wash',()=>{
 assert.match(ui,/if\(crashAllowed&&!isReggae\)p\.crash/);
 assert.match(ui,/if\(isReggae\)\{p\.crash=\[\];p\.ride=\[\]/);
});
