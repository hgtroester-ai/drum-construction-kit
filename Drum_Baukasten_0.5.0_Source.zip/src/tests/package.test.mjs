import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
test('portable archive has manifest, entry, package metadata, settings, solo engine and licence',()=>{
 assert.ok(fs.existsSync('Drum_Baukasten_0.5.0.ablx'));
 const listing=execFileSync('unzip',['-Z1','Drum_Baukasten_0.5.0.ablx'],{encoding:'utf8'}).trim().split('\n');
 for(const p of ['manifest.json','dist/extension.js','dist/package.json','LICENSE.md'])assert.ok(listing.includes(p),`missing ${p}`);
 const manifest=JSON.parse(fs.readFileSync('manifest.json','utf8'));
 assert.equal(manifest.version,'0.5.0');
 const bundle=fs.readFileSync(manifest.entry,'utf8');
 assert.match(bundle,/BUILD 0\.5\.0/);
 assert.match(bundle,/audio-settings\.json/);
 assert.match(bundle,/Drum Construction Kit/);
 assert.match(bundle,/generateSoloNotes/);
 assert.match(bundle,/createSolo/);
});
