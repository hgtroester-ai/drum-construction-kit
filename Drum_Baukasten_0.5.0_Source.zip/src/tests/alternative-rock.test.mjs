import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync('src/ui.ts','utf8');
const model=fs.readFileSync('src/model.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.json','utf8'));
test('Alternative Rock has a dedicated dynamic quiet-to-loud groove engine',()=>{
 assert.match(ui,/function applyAlternativeRockPersonality\(p,bar,section,influence\)/);
 assert.match(ui,/const quiet=section\.type==='Verse'\|\|section\.type==='Bridge'/);
 assert.match(ui,/if\(localGenre==='alternativeRock'\)applyAlternativeRockPersonality/);
 assert.match(ui,/Alternative Rock quiet passages/);
 assert.match(ui,/Alternative Rock loud passages/);
});
test('Alternative Rock uses asymmetrical phrase fills and syncopated accents',()=>{
 assert.match(ui,/Full-Bar Fill Intelligence: replace the scheduled fill window/);
 assert.match(ui,/function generateIntelligentFill\(seed,genre,drummer,sectionType,intensity\)/);
 assert.match(model,/alternativeRock:\[P\(\[0,8\],\[4,12\]/);
});
test('Alternative Rock tempo and release versions are retained',()=>{
 assert.match(ui,/alternativeRock:118/);
 assert.equal(pkg.version,'0.5.0');
 assert.equal(manifest.version,'0.5.0');
});

test('Alternative Rock solo has phrase-based call and response with breathing bars and profile-aware voicing',()=>{
 const solo=fs.readFileSync('src/soloEngine.ts','utf8');
 assert.match(solo,/Two-bar call\/response/);
 assert.match(solo,/bar%4===3/);
 assert.match(solo,/const offbeat=profile==='offbeatSka'\|\|profile==='brokenBeats'/);
 assert.match(solo,/const rolling=profile==='rollingToms'\|\|profile==='dynamicToms'/);
 assert.match(solo,/const precision=profile==='precisionFills'/);
});
test('Solo creation forwards the selected drummer profile and GUI shows current build label',()=>{
 const ext=fs.readFileSync('src/extension.ts','utf8');
 assert.match(ext,/String\(msg\.drummerStyle\|\|\"powerSwing\"\)/);
 assert.match(ui,/\$\{esc\(BUILD_LABEL\)\}/);
 assert.match(ui,/drummerStyle:\$\('drummerStyle'\)\.value/);
});
