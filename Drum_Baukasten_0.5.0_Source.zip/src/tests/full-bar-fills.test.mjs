import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('Full-Bar Fill Intelligence declares full-bar replacement and song-wide fill signature rotation',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 assert.match(source,/const usedFillSignatures=new Set\(\)/);
 assert.match(source,/function generateIntelligentFill\(seed,genre,drummer,sectionType,intensity\)/);
 assert.match(source,/Full-Bar Fill Intelligence: replace the scheduled fill window/);
 assert.match(source,/notes\[ni\]\.time>=fillStartTime-\.001/);
 assert.match(source,/usedFillSignatures\.has\(signature\)/);
 assert.match(source,/const isSectionEnd=bar===s\.bars-1/);
 assert.match(source,/Phrase Fill Schedule 0\.3\.18/);
 assert.match(source,/phraseFills\.set\(7,4\)/);
 assert.doesNotMatch(source,/fillEvery|fillDefault|Fill interval/);
});

test('Full-Bar Fill Intelligence keeps One-Bar Outro out of regular fill generation',()=>{
 const source=fs.readFileSync('src/ui.ts','utf8');
 assert.match(source,/const isOutroFinal=s\.type==='Outro'&&isSectionEnd;if\(!isOutroFinal\)/);
 assert.match(source,/One-Bar Outro: one sustained kick and crash together on beat one, then silence/);
});
