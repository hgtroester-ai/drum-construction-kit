import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);

test('Blues Rock full solo uses a swung ride motif and a recurring kick/snare statement',()=>{
 for(const bars of [16,32]){
  const notes=solo.generateSoloNotes('bluesRock',bars,'fullSolo',75,65,23);
  const first=notes.filter(n=>n.time<4);
  for(const step of [0,0.75,1,1.75,2,2.75,3,3.75])
   assert.ok(first.some(n=>n.pitch===51&&Math.abs(n.time-step)<1e-9),`missing swung ride at ${step}`);
  assert.ok(first.some(n=>n.pitch===36&&n.time===0));
  assert.ok(first.some(n=>n.pitch===38&&n.time===1));
  assert.ok(first.some(n=>n.pitch===38&&n.time===3));
 }
});

test('Blues Rock 16- and 32-bar forms develop phrases and finish with a shared final hit',()=>{
 for(const bars of [16,32]){
  const notes=solo.generateSoloNotes('bluesRock',bars,'fullSolo',75,70,29);
  const last=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(last.length>=4,'last bar must continue the groove, not collapse to one hit');
  assert.ok(!last.some(n=>n.pitch===49),'Complete Solo must not force a final crash');
  assert.ok(notes.every(n=>n.time<bars*4));
  assert.ok(notes.some(n=>[43,47,50].includes(n.pitch)));
 }
});

test('Blues Rock motif variations remain deterministic for a seed and differ across seeds',()=>{
 const a=solo.generateSoloNotes('bluesRock',16,'fullSolo',75,65,17);
 const b=solo.generateSoloNotes('bluesRock',16,'fullSolo',75,65,17);
 const c=solo.generateSoloNotes('bluesRock',16,'fullSolo',75,65,18);
 assert.deepEqual(a,b);
 assert.notDeepEqual(a,c);
});
