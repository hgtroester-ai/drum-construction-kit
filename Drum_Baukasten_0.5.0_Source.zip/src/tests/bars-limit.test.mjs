import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('section bar input is capped at 16 and clip labels include bar count',()=>{
 const ui=fs.readFileSync('src/ui.ts','utf8');
 assert.match(ui,/data-prop="bars" type="number" min="1" max="16"/);
 assert.match(ui,/Math\.min\(16,Math\.round\(Number\(e\.target\.value\)\|\|1\)\)/);
 assert.match(ui,/name:section\.name\+['"] · ['"]\+section\.bars\+['"] Bars['"]/);
});

test('Live export caps clip duration and excludes notes beyond clip boundary',()=>{
 const extension=fs.readFileSync('src/extension.ts','utf8');
 assert.match(extension,/createMidiClip\(Math\.max\(1,Math\.min\(16,Math\.round\(Number\(section\.bars\)\|\|1\)\)\)\*4\)/);
 assert.match(extension,/section\.notes\.filter\(n=>Number\.isFinite\(n\.time\)&&n\.time>=0&&n\.time<clipBars\*4-\.01\)/);
 assert.match(extension,/duration:Math\.max\(\.01,Math\.min\(Number\(n\.duration\)\|\|\.12,clipBars\*4-\.01-n\.time\)\)/);
});

test('model clamps generated section lengths to 16 bars',()=>{
 const model=fs.readFileSync('src/model.ts','utf8');
 assert.match(model,/bars:Math\.max\(1,Math\.min\(16,Math\.round\(Number\(section\.bars\)\|\|1\)\)\)/);
});
