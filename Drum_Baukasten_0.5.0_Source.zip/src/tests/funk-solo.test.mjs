import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const solo=await import(pathToFileURL(path.resolve('dist/modules/soloEngine.js')).href);
test('Funk Complete Solo keeps pocket, ghost notes and a full final bar at 8/16/32 bars',()=>{
 for(const bars of [8,16,32]){
  const notes=solo.generateSoloNotes('funk',bars,'fullSolo',78,76,29);
  const final=notes.filter(n=>n.time>=(bars-1)*4&&n.time<bars*4);
  assert.ok(final.length>=12,`Funk final bar too sparse at ${bars} bars`);
  assert.ok(final.some(n=>n.pitch===36),'syncopated kick must continue');
  assert.ok(final.some(n=>n.pitch===38&&n.velocity<85),'quiet snare ghost notes must remain');
  assert.ok(final.some(n=>n.pitch===42),'closed hi-hat pocket must continue');
  assert.ok(!final.some(n=>n.pitch===49),'Complete Solo must not force a final crash');
 }
});
test('Funk solo has dynamic hat, syncopated kick and tom call-and-response vocabulary',()=>{
 const notes=solo.generateSoloNotes('funk',16,'fullSolo',82,82,37);
 assert.ok(notes.some(n=>n.pitch===36&&[3,5,6,7,9,10,11,14,15].includes(Math.round((n.time%4)*4))));
 assert.ok(notes.some(n=>n.pitch===42&&n.duration<.1));
 assert.ok(notes.some(n=>[43,47].includes(n.pitch)));
 assert.ok(notes.some(n=>n.pitch===38&&n.velocity<70));
});
test('Funk solo is deterministic by seed and changes with a new seed',()=>{
 const a=solo.generateSoloNotes('funk',16,'fullSolo',75,70,11);
 const b=solo.generateSoloNotes('funk',16,'fullSolo',75,70,11);
 const c=solo.generateSoloNotes('funk',16,'fullSolo',75,70,12);
 assert.deepEqual(a,b);assert.notDeepEqual(a,c);
});
