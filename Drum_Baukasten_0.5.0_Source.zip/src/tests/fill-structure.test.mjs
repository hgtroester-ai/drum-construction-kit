import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js';
const source=fs.readFileSync('src/model.ts','utf8');
const js=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}}).outputText;
const sandbox={exports:{}};vm.runInNewContext(js,sandbox);
const {generateSectionNotes}=sandbox.exports;
const section={id:'v',type:'Verse',name:'Verse',bars:16,intensity:65,variant:1};
function notesInBar(notes,bar){return notes.filter(n=>n.time>=bar*4&&n.time<(bar+1)*4)}
test('16-bar sections place short fills in bars 4 and 12, full fills in bars 8 and 16',()=>{
 const notes=generateSectionNotes('classicRock',section,7);
 const b4=notesInBar(notes,3),b8=notesInBar(notes,7),b12=notesInBar(notes,11),b16=notesInBar(notes,15);
 assert.ok(b4.some(n=>n.time>=14),'bar 4 contains a short fill in its final beat or half');
 assert.ok(b8.some(n=>n.time<29),'bar 8 full fill starts at beat one');
 assert.ok(b12.some(n=>n.time>=47),'bar 12 contains a short fill in its final beat or half');
 assert.ok(b16.some(n=>n.time<61),'bar 16 contains full-bar ending fill');
 assert.ok(!b4.some(n=>n.pitch===42&&n.time>=14),'bar 4 groove is replaced only in the fill window');
});
test('8-bar midpoint uses a half-bar fill; 4-bar midpoint uses a quarter-bar fill',()=>{
 const eight=generateSectionNotes('punk',{...section,bars:8},7);
 const four=generateSectionNotes('punk',{...section,bars:4},7);
 const b4=notesInBar(eight,3),b2=notesInBar(four,1);
 assert.ok(b4.some(n=>n.time>=13),'8-bar midpoint fill starts in second half');
 assert.ok(b4.some(n=>n.time<13),'8-bar midpoint preserves first half groove');
 assert.ok(b2.some(n=>n.time>=7),'4-bar midpoint fill starts in final beat');
 assert.ok(b2.some(n=>n.time<7),'4-bar midpoint preserves first three beats');
});
test('Punk fills use fast sixteenth-grid movement and rotate techniques',()=>{
 const signatures=new Set();
 for(let seed=0;seed<16;seed++) {
   const a=generateSectionNotes('punk',{...section,bars:8},seed);
   const fill=notesInBar(a,7);
   const pitches=new Set(fill.map(n=>n.pitch));
   if(pitches.has(50)&&pitches.has(47)&&pitches.has(43)) signatures.add('toms');
   if(fill.filter(n=>n.pitch===38).length>=8) signatures.add('roll');
   if(pitches.has(36)&&pitches.has(38)&&pitches.has(50)) signatures.add('linear');
   if(fill.some(n=>Math.abs(n.time*3-Math.round(n.time*3))<1e-7 && Math.abs(n.time*4-Math.round(n.time*4))>1e-7)) signatures.add('triplet');
 }
 assert.ok(signatures.size>=3,'Punk rotates through multiple fill grammars');
});
test('Alternative Rock exposes all four advanced fill grammars across phrase variations',()=>{
 const signatures=new Set();
 for(let seed=0;seed<24;seed++) {
   const notes=generateSectionNotes('alternativeRock',{...section,bars:4,variant:seed%7},seed);
   const fill=notesInBar(notes,3);
   const times=fill.map(n=>n.time);
   const pitches=new Set(fill.map(n=>n.pitch));
   if(times.some(t=>Math.abs(t*3-Math.round(t*3))<1e-7 && Math.abs(t*4-Math.round(t*4))>1e-7)) signatures.add('triplet');
   if(times.some(t=>Math.abs(t*8-Math.round(t*8))<1e-7 && Math.abs(t*4-Math.round(t*4))>1e-7)) signatures.add('roll');
   if(pitches.has(50)&&pitches.has(47)&&pitches.has(43)) signatures.add('tom-run');
   if(pitches.has(36)&&pitches.has(38)&&pitches.has(50)) signatures.add('linear');
 }
 assert.ok(signatures.has('triplet'),'triplet fill appears');
 assert.ok(signatures.has('roll'),'snare roll appears');
 assert.ok(signatures.has('tom-run'),'tom run appears');
 assert.ok(signatures.has('linear'),'linear fill appears');
});
test('Alternative Rock Verse and Chorus have distinct groove identities',()=>{
 const verse=generateSectionNotes('alternativeRock',{...section,type:'Verse',bars:4,variant:2,intensity:55},5);
 const chorus=generateSectionNotes('alternativeRock',{...section,type:'Chorus',bars:4,variant:2,intensity:85},5);
 const groove=(notes)=>notes.filter(n=>n.time<12).map(n=>`${n.pitch}:${Math.round((n.time%4)*16)/16}`).sort().join('|');
 assert.notEqual(groove(verse),groove(chorus),'Verse and Chorus groove patterns differ');
 assert.ok(chorus.filter(n=>n.pitch===49||n.pitch===46).length>=verse.filter(n=>n.pitch===49||n.pitch===46).length,'Chorus has at least as much cymbal lift');
});
