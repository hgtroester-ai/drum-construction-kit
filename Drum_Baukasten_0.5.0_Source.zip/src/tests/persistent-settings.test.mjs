import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { readSettings, writeSettings } from '../dist/modules/audioSettings.js';

test('complete GUI state survives extension dialog sessions', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dck-full-settings-'));
  const state = { version: 1, genre: 'funk', controls: { bpm: '108', soloType: 'tradingFours', soloBars: '16', grooveVariation: '72' }, sections: [{ id: 'verse', name: 'Verse', bars: 8, intensity: 75, fillEvery: 4, variant: 2 }] };
  try {
    assert.equal(readSettings(directory).previewVolume, 70);
    writeSettings(directory, 38, state);
    const restored = readSettings(directory);
    assert.equal(restored.previewVolume, 38);
    assert.deepEqual(restored.uiState, state);
    writeSettings(directory, 44, state);
    assert.deepEqual(readSettings(directory).uiState, state);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});

test('dialog serializes all state and sends it on Cancel, arrangement and solo close paths', () => {
  const ui = fs.readFileSync('src/ui.ts', 'utf8');
  const extension = fs.readFileSync('src/extension.ts', 'utf8');
  assert.match(ui, /function collectSettings\(\)/);
  assert.match(ui, /sections:JSON\.parse\(JSON\.stringify\(sections\)\)/);
  assert.match(ui, /uiState:collectSettings\(\)/g);
  assert.match(ui, /function restoreSettings\(\)/);
  assert.match(extension, /readSettings\(storageDirectory\)/);
  assert.match(extension, /writeSettings\(storageDirectory,msg\.previewVolume,msg\.uiState\)/);
});
