import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync('src/ui.ts','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.json','utf8'));
test('Hip-Hop has dedicated Deep Pocket and Broken Beats engines',()=>{assert.match(ui,/function applyHipHopPersonality\(p,drummer,bar,section,influence\)/);assert.match(ui,/drummer==='deepPocket'.*half-time snare on beat three/s);assert.match(ui,/drummer==='brokenBeats'.*syncopated kick and displaced snare/s);assert.match(ui,/if\(localGenre==='hipHop'\)applyHipHopPersonality/);});
test('Hip-Hop tempo remains 88 BPM and version metadata is synchronized',()=>{assert.match(ui,/hipHop:88/);assert.equal(pkg.version,'0.5.0');assert.equal(manifest.version,'0.5.0');});
test('Hip-Hop variation stays restrained and cymbal lanes are cleared',()=>{assert.match(ui,/if\(genre==='hipHop'\).*return/s);assert.match(ui,/p\.crash=\[\];p\.ride=\[\];p\.hiTom=\[\];p\.midTom=\[\];p\.lowTom=\[\]/);});
