import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
const modelPath=path.resolve('dist/modules/model.js');
let model;
try { model = await import(pathToFileURL(modelPath).href); } catch { model = null; }
test('all eight requested genres are available',()=>{
 assert.ok(model,'Run the portable build before model tests');
 assert.deepEqual(model.GENRES.map(g=>g.key),['classicRock','bluesRock','alternativeRock','punk','reggae','ska','funk','hipHop']);
});
test('default arrangement has coherent section lengths and stable note data',()=>{
 const {DEFAULT_SECTIONS,buildArrangement}=model;
 const a=buildArrangement('classicRock',DEFAULT_SECTIONS,23);
 const b=buildArrangement('classicRock',DEFAULT_SECTIONS,23);
 assert.equal(a.totalBars,61);
 assert.equal(a.sections.length,8);
 assert.ok(a.notes.length>100);
 assert.deepEqual(a.notes,b.notes);
 assert.ok(a.notes.every(n=>n.pitch>=0&&n.pitch<=127&&n.velocity>=1&&n.velocity<=127&&n.time>=0));
});
test('genre changes produce distinct rhythmic signatures',()=>{
 const {DEFAULT_SECTIONS,buildArrangement}=model;
 const funk=buildArrangement('funk',DEFAULT_SECTIONS,10).notes.map(n=>`${n.pitch}@${n.time}`).join('|');
 const reggae=buildArrangement('reggae',DEFAULT_SECTIONS,10).notes.map(n=>`${n.pitch}@${n.time}`).join('|');
 assert.notEqual(funk,reggae);
});
test('section lengths affect overall arrangement duration',()=>{
 const {DEFAULT_SECTIONS,buildArrangement}=model;
 const sections=DEFAULT_SECTIONS.map(s=>({...s}));sections[0].bars=6;
 assert.equal(buildArrangement('ska',sections,1).totalBars,63);
});
test('every genre can produce non-empty MIDI notes',()=>{
 const {GENRES,DEFAULT_SECTIONS,buildArrangement}=model;
 for(const g of GENRES){const a=buildArrangement(g.key,DEFAULT_SECTIONS,2);assert.ok(a.notes.length>0,g.key);assert.equal(a.totalBars,61);}
});

test('UI provides eight drummer profiles and adjustable style influence',()=>{const ui=fs.readFileSync('src/ui.ts','utf8');for(const id of ['powerSwing','texasShuffle','heavyBackbeat','straightEighths','oneDrop','offbeatSka','ghostNoteFunk','deepPocket'])assert.ok(ui.includes('value=\"'+id+'\"')||ui.includes("case '"+id+"'"));assert.match(ui,/applyDrummerStyle/);assert.match(ui,/styleInfluence/);});
