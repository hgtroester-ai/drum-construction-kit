# Building Drum Construction Kit 0.4.4

1. Use Node.js and TypeScript compiler (`tsc`).
2. Run `node build-portable.mjs` to create `Drum_Baukasten_0.4.4.ablx`.
3. Run `npm test` for the automated regression suite.
4. Package the complete source tree and test protocol as `Drum_Baukasten_0.4.4_Source.zip`.

Version 0.4.4 adds a dedicated Punk Raw Energy full-solo composer: driving eighth-note kick identity, blunt backbeat, phrase-shaped snare/tom fills, flam accents, short stop-and-go breaks and a shared final hit. Classic Rock, Blues Rock and Alternative Rock solo engines remain unchanged. Automated tests do not replace host-side playback testing in Ableton Live 13 Beta.
