# Third-party notices

This file identifies known third-party names and components based on the current source package. It is not a substitute for checking the complete dependency tree and the exact license files of each redistributed component.

## Ableton Extensions SDK
The project uses the Ableton Extensions SDK (`@ableton-extensions/sdk`, version 1.0.0-beta.0) to communicate with Ableton Live. The SDK is a third-party component and is governed by the license and distribution terms supplied by Ableton. The public source archive does not include the SDK or CLI tarball archives; obtain the SDK separately from its official source and comply with its terms. The built extension bundles SDK runtime code needed to run; confirm that redistribution of that runtime in the `.ablx` complies with the applicable SDK terms before public release.

## Ableton and Ableton Live
Ableton and Ableton Live are names and/or trademarks of their respective owner. They are mentioned solely to identify the host application and compatibility. This project is independent and is not endorsed by Ableton AG.

## Instrument and MIDI references
The extension generates MIDI notes and uses generic drum-role mappings. Users may use those MIDI clips with their own instruments. No third-party instrument samples or commercial drum-library audio are intentionally claimed as part of this source package.

## Embedded artwork and preview resources
The project includes its own bundled logo and banner resources. Their origin and redistribution rights should be confirmed by the project maintainer before public release. If any resource was sourced from a third party, add its creator, source, license, and required attribution here.

## Dependency inventory
The source package uses TypeScript and a portable build script. The SDK and CLI are not redistributed in the public source archive. Review the installed dependency tree and each package's license before publishing a complete build environment.
