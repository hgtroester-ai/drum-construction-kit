# Free Music Creator License — project-specific license draft

Copyright © 2026 Hans-Georg Tröster (HGT).

This license applies only to original project material for Drum Construction Kit / Drum Baukasten. It does not replace or override licenses for third-party components, which remain subject to their own terms as described in `THIRD-PARTY-NOTICES.md`.

## 1. Permission to use
You may download and use this extension free of charge for personal, educational, professional, and commercial music production. You may create, release, perform, distribute, license, and sell music made using the extension. This permission applies to your music output, not to ownership of the extension or its source code.

## 2. Restrictions on the extension itself
Without prior written permission from the copyright holder, you may not sell, sublicense, or commercially redistribute the extension or a modified version of it as a software product. You may not remove or misrepresent the copyright, credit, or license notices. You may not claim that you created the original project.

## 3. Sharing
You may direct others to the official project download page. Redistribution of the extension package or modified builds is not permitted without prior written permission, except where a mandatory legal right or a separate third-party license requires otherwise.

## 4. Modifications
This license does not grant permission to publicly distribute modified versions or derivative software products without prior written permission from the copyright holder, subject to applicable law and third-party license terms.

## 5. Third-party components and trademarks
Third-party components are not relicensed by this document. Their respective license terms apply. Names of products and companies are used only where necessary to identify compatibility or dependencies; no endorsement is implied.

## 6. No warranty
The project is provided “as is” to the extent permitted by applicable law. No warranty is provided for fitness, uninterrupted operation, or compatibility with every system. Nothing in this clause limits rights that cannot legally be excluded.

## 7. Questions and permission requests
For written permission to redistribute or commercially use the extension itself, contact the copyright holder through the project's official publication channel.

## Important status note
This is a project-specific license draft, not an OSI-approved open-source license. Its restrictions may not be enforceable against every form of copying, functional imitation, or GUI similarity. Third-party rights and mandatory legal exceptions remain unaffected.
