## Version 0.3.18 – Solo Intelligence
Full Solo gains genre-aware rudiments, phrase-positioned technical passages, a transformed motif reprise, and complexity-aware articulation. Existing solo types, song hand-offs and the Solo Outro invariant remain intact.

## Version 0.3.17 – Phrase Fill Refinement
Fills follow the length and internal phrasing of each song section; the obsolete Fill Interval controls have been removed. A 16-bar section receives short fills in bars 4 and 12 (alternating quarter- and half-bar lengths), full-bar fills in bars 8 and 16. A 12-bar section receives shorter fills in bars 4 and 8 and a full-bar ending. An 8-bar section receives a half-bar midpoint fill and full-bar ending; a 4-bar section receives a quarter-bar midpoint fill and full-bar ending. The schedule applies to all genres. Fill Repeat Control remains available to reduce repeated figures. Section Intensity remains a velocity/energy control and does not determine fill placement. The One-Bar Outro remains unchanged.

# Drum Construction Kit 0.3.2

Independent Ableton Live extension by HGT, supported with AI.

Version 0.3.2 moves the complete Audio Preview panel to the far-left sidebar. Preview, Stop and Preview Volume are grouped beneath the genre selector; the main workflow is renumbered to sections 4 and 5. Audio playback and saved volume behavior are unchanged.

The existing genre-specific Solo Personalities from version 0.3.1 remain available:
- Rock & Metal: forceful kick/snare figures, progressive tom runs, dynamic build and a marked ending.
- Jazz & Fusion: ride-led timekeeping, syncopated snare language and melodic tom phrases. Blues Rock is used as the available jazz-influenced interpretation; no separate Jazz genre is added.
- Funk & Soul: syncopated kick, ghost-note snare, compact motifs and danceable breaks.
- Pop & Hip-Hop Break: short, recognizable break motifs, space and a clear return to the main groove.
- Reggae and Ska retain their own One Drop / offbeat identity.

The Solo Engine creates a standalone drum-only MIDI clip in the selected MIDI track and free Session View slot. Choose Full Solo, Drum Break, Trading Fours or Solo Outro, set the length (1–32 bars), dynamic development and technical complexity. Place the generated clip wherever it belongs in the song. Other instrument tracks are not automatically muted or edited.

The extension retains the existing arrangement builder, embedded MP3 Audio Preview and persistent Preview Volume settings.

Run `node build-portable.mjs` to build the `.ablx` package and `node --test tests/*.test.mjs` to run the automated tests.


## Persistent settings (0.3.3)
The extension stores the last interface state in Ableton Live's per-extension persistent storage directory. It restores the selected genre, arrangement and section settings, drummer/groove controls, Solo Engine settings, Preview Volume, and the last target track/slot where that slot is still available. State is written when the extension dialog closes via Cancel or either Create action.


## Version 0.3.5 – Solo Phrasing Intelligence
Alternative Rock solos use repeated and varied motifs, call-and-response phrasing, breathing space and a controlled climax. The selected drummer profile shapes the solo vocabulary. The bottom-left GUI now reports the actual generated build label.


## 0.3.5 – Solo Dramaturgy Engine
The Solo Engine now shapes the performance with a non-linear arc: a more restrained opening, a gradual build, a clear high point and a slight release into the cadence. Full Solo closes with a compact snare/crash accent inside the final bar. The established one-bar Solo Outro ending is preserved.

### Version 0.3.7 – Genre-Aware Solo Engine
The solo engine now distinguishes five target styles: Rock/Hard Rock, Blues Rock, Funk, Punk and Alternative Rock. Each uses its own rhythmic vocabulary while retaining the 0.3.5 dramaturgical arc and existing solo controls.

### Version 0.3.8 – Solo Interaction
Full solos now use more deliberate two-bar call/response between kick, snare and tom voices. Longer solos recall the opening motif with a lighter, altered voicing. The GUI remains unchanged.


### Version 0.3.9 – Song Integration
The Solo Engine can now shape its opening and ending according to the selected preceding and following song sections. The solo remains a standalone MIDI clip in Session View; the user places it in the song arrangement.


### Version 0.3.9 – Song Integration (source draft)
The solo dialog adds preceding/following song-section context. This source snapshot has not yet passed the build or automated test suite; do not treat it as an installable release.

## Version 0.3.9 – Song Integration
The Solo Engine can now shape its entrance based on the preceding song section (Verse, Chorus, Bridge, Intro) and its Full Solo ending based on the destination (Chorus, Verse, Bridge, Outro). The solo remains a standalone MIDI clip in Session View; move it to the desired song position in Live.

### Version 0.3.11 – Full-Bar Fill Intelligence
Scheduled fills and section-ending fills now occupy a complete 4/4 bar. The fill replaces the regular groove for that measure, spans from beat one through the final sixteenth, and rotates through 32 deterministic rhythm/voicing combinations to avoid repeated phrases across the song.

### Version 0.3.13 – Fill Density & Fast Hands
Mixed quarter-, eighth- and sixteenth-note fill phrasing, with faster-hand bias for Punk and Rock and alternating sparse/busy phrases for Alternative Rock.

## 0.3.14 – Fill Structure & Punk Dynamics
Intermediate fill interval events alternate quarter-bar and half-bar pickups; the final bar of each section receives a full-bar fill. Fill windows replace the underlying groove. Punk uses faster sixteenth-grid orchestration with frequent snare, kick and tom changes; Rock and Alternative Rock mix restrained and denser phrases.


## Version 0.3.15 – Advanced Fill Techniques & Alternative Rock Variation
Automatic genre-aware Tom Runs, Snare Rolls with crescendos, linear/funk phrasing and triplet/shuffle fills. Alternative Rock receives distinct Verse, Chorus and Bridge groove identities with more varied fills. The GUI remains unchanged.


## Solo Intelligence 0.3.18
The Full Solo engine now uses a genre-aware rudiment vocabulary (single/double strokes, paradiddle, flam, drag and shuffle triplet figures), phrase-positioned technical passages, and a transformed return of the opening motif. Technical density follows the Complexity control and the musical arc; Dynamics continues to shape velocity and energy. Existing solo types and the Solo Outro ending remain unchanged.


## Version 0.4.2 – Blues Rock Shuffle Motif Solo

Blues Rock full solos now use a dedicated motif-led shuffle language: swung ride ostinato, recurring kick/snare statement, call-and-response tom answers, restrained ghost notes, phrase turnarounds and a decisive final hit. The 16- and 32-bar forms develop the same blues-rock identity rather than chaining unrelated fills.

## Version 0.4.1 – Classic Rock Motif-Based Hybrid Solo

Classic Rock full solos now follow a connected musical motif across 16 bars: establish the theme, answer it, transform it across the toms, build intensity in controlled phrases, then resolve with a clear shared final downbeat. Seed variation and technical complexity shape phrase details without losing the motif.

## Version 0.4.0 – Classic Rock Solo Drum
The Classic Rock Full Solo now uses a composed eight-bar performance arc with a crash-led opening, triplet hand-foot figures, tom-led syncopation, sixteenth-note runs, flam-like accents, and a decisive kick/crash ending on beat one. Longer solos develop through transformed eight-bar cycles. Other genre solo engines remain unchanged.

## Version 0.4.4 – Alternative Rock Broken Motif Solo
Alternative Rock full solos use broken-backbeat motifs, intentional dynamic drops, syncopated answers, phrase-ending fills and grace-note flams. The dedicated solo composer supports 16- and 32-bar forms and resolves with a shared kick/snare/crash downbeat. Classic Rock and Blues Rock retain their dedicated motif-led solo engines.

## Version 0.4.5 – Reggae Drum Solo
The Reggae solo engine creates 16- and 32-bar performances around a clear One Drop foundation, developing through Rockers drive into a Steppers peak. The Drummer Profile selector now includes One Drop, Rockers and Steppers as separate choices. The solo uses dry rimshot accents, restrained hi-hat pulse, call-and-response tom phrases, breathing bars and a decisive final ensemble hit.
