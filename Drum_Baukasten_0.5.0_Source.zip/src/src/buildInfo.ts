// Automatically regenerated on every portable build.
export const BUILD_LABEL = "BUILD 0.5.0";
