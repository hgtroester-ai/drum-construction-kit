import type { Genre, Note } from './model';

const GM={kick:36,snare:38,rim:37,hat:42,openHat:46,crash:49,ride:51,hiTom:50,midTom:47,lowTom:43};
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const choose=<T,>(items:T[],i:number):T=>items[((i%items.length)+items.length)%items.length];

/** Non-linear performance arc: establish, develop, peak, then make room for the cadence. */
function dramaturgyCurve(position:number):number{
 const t=clamp(position,0,1);
 if(t<.25)return .18+(t/.25)*.22;
 if(t<.70)return .40+((t-.25)/.45)*.52;
 if(t<.88)return .92+((t-.70)/.18)*.08;
 return 1-((t-.88)/.12)*.24;
}

export type SoloPersonality='rockHardRock'|'bluesRock'|'funkSoul'|'punkDrive'|'alternativeRock'|'popHipHop'|'hipHopBoomBap'|'reggaeSka';
export function getSoloPersonality(genre:Genre):SoloPersonality{
 if(genre==='bluesRock')return 'bluesRock';
 if(genre==='funk')return 'funkSoul';
 if(genre==='punk')return 'punkDrive';
 if(genre==='alternativeRock')return 'alternativeRock';
 if(genre==='classicRock')return 'rockHardRock';
 if(genre==='hipHop')return 'hipHopBoomBap';
 if(genre==='reggae'||genre==='ska')return 'reggaeSka';
 return 'rockHardRock';
}

/** Genre-aware solo phrasing. Sixteenth-note steps are expressed in quarter-note beats. */
export function generateSoloNotes(genre:Genre,bars:number,soloType:string,intensity=75,complexity=65,seed=23,drummerStyle="powerSwing",previousSection="verse",nextSection="chorus"):Note[]{
 const length=clamp(Math.round(Number(bars)||8),1,32),power=clamp(intensity,0,100)/100,skill=clamp(complexity,0,100)/100;
 const personality=getSoloPersonality(genre),out:Note[]=[];
 const add=(bar:number,steps:number[],pitch:number,velocity:number,duration=.12)=>{
  for(const step of steps)out.push({pitch,time:bar*4+step*.25,duration,velocity:clamp(Math.round(velocity),1,127)});
 };
 const removeFinalCrash=()=>{const start=(length-1)*4;for(let i=out.length-1;i>=0;i--)if(out[i].time>=start&&out[i].pitch===GM.crash)out.splice(i,1);};
 const continueFullSoloThroughLastBar=()=>{
  if(soloType!=='fullSolo'||length<2)return;
  const last=length-1, start=last*4;
  // Find the nearest genuinely played bar, not an intentional breath bar.
  let source:Note[]=[];
  for(let bar=last-1;bar>=0;bar--){
   const candidate=out.filter(n=>n.time>=bar*4&&n.time<(bar+1)*4);
   if(candidate.length>=4){source=candidate;break;}
  }
  // Replace any isolated cadence/pickup in the last bar with a continuation
  // of the solo groove. This is deliberately not a fill or an ending hit.
  for(let i=out.length-1;i>=0;i--)if(out[i].time>=start)out.splice(i,1);
  for(const n of source){
   const relative=n.time%4;
   out.push({pitch:n.pitch,time:start+relative,duration:n.duration,velocity:clamp(Math.round(n.velocity*.94),1,127)});
  }
 };
 // Drum Break is a short, syncopated interruption: sparse setup, explosive
 // two-bar burst, then a compact pickup. It is intentionally not a solo arc.
 if(soloType==='drumBreak'){
  const last=length-1;
  const motifs:Record<string,{kick:number[];snare:number[];tom:number[];cymbal:number}>={
   classicRock:{kick:[0,3,8,11],snare:[2,7,10,14],tom:[12,13,14,15],cymbal:GM.crash},
   bluesRock:{kick:[0,6,10],snare:[3,7,11,14],tom:[8,10,12,15],cymbal:GM.ride},
   alternativeRock:{kick:[0,5,8,13],snare:[3,6,11,14],tom:[9,11,13,15],cymbal:GM.crash},
   punk:{kick:[0,2,4,7,8,11,12,14],snare:[3,6,10,13],tom:[12,13,14,15],cymbal:GM.crash},
   reggae:{kick:[0,8],snare:[3,7,11,14],tom:[10,12,14,15],cymbal:GM.rim},
   ska:{kick:[0,6,8,14],snare:[2,5,10,13],tom:[11,12,14,15],cymbal:GM.crash},
   funk:{kick:[0,3,7,10,14],snare:[2,6,9,13],tom:[8,11,13,15],cymbal:GM.crash},
   hipHop:{kick:[0,7,10],snare:[3,6,11,14],tom:[9,12,14,15],cymbal:GM.crash}
  };
  const m=motifs[genre]||motifs.classicRock;
  for(let bar=0;bar<length;bar++){
   const v=clamp(66+power*38+(bar/Math.max(1,length-1))*12,1,120);
   if(bar===0){add(bar,[0,8],GM.kick,v-12);add(bar,[4,12],GM.snare,v-15);continue;}
   add(bar,m.kick,GM.kick,v+5);add(bar,m.snare,GM.snare,v+2);
   add(bar,m.tom,bar%2?GM.lowTom:GM.midTom,v-2);
   if(bar===1||bar===last)add(bar,[0],m.cymbal,v+4);
  }
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Solo Outro is a distinct song-ending mode for every genre. Genre-specific
 // lead phrasing runs up to the reserved final bar; only this mode gets the
 // sustained kick + crash downbeat.
 if(soloType==='soloOutro'){
  const patterns:Record<string,{kick:number[];snare:number[];hat:number[];tom:number[];ride?:number[]}>= {
   classicRock:{kick:[0,8],snare:[4,12],hat:[0,2,4,6,8,10,12,14],tom:[10,12,14]},
   bluesRock:{kick:[0,8],snare:[4,12],hat:[0,3,6,9,12,15],tom:[8,11,14],ride:[0,4,8,12]},
   alternativeRock:{kick:[0,6,8,14],snare:[4,11,12],hat:[0,4,8,12],tom:[9,12,14]},
   punk:{kick:[0,2,4,6,8,10,12,14],snare:[4,12],hat:[0,2,4,6,8,10,12,14],tom:[12,13,14,15]},
   reggae:{kick:[8],snare:[8],hat:[0,4,8,12],tom:[10,12,14]},
   ska:{kick:[0,8],snare:[4,12],hat:[2,6,10,14],tom:[10,12,14]},
   funk:{kick:[0,6,10],snare:[4,12],hat:[0,2,4,6,8,10,12,14],tom:[9,11,14]},
   hipHop:{kick:[0,10],snare:[4,12],hat:[0,4,8,12],tom:[10,12,14]}
  };
  const pattern=patterns[genre]||patterns.classicRock;
  const outroBars=Math.max(0,length-1);
  for(let bar=0;bar<outroBars;bar++){
   const progress=bar/Math.max(1,length-1),v=clamp(62+progress*32+power*17,1,116);
   add(bar,pattern.kick,GM.kick,v+5,.12);
   add(bar,pattern.snare,genre==='reggae'?GM.rim:GM.snare,v,.10);
   add(bar,pattern.hat,genre==='bluesRock'?GM.ride:genre==='reggae'||genre==='ska'?GM.openHat:GM.hat,v-20,.08);
   if(pattern.ride)add(bar,pattern.ride,GM.ride,v-13,.10);
   if(bar%2===1||bar===outroBars-1)add(bar,pattern.tom,GM.lowTom,v+8,.09);
  }
  const last=length-1;add(last,[0],GM.kick,127,4);add(last,[0],GM.crash,127,4);
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.5.0: Hip-Hop — pocket-first solo with boom-bap phrasing, swung hats,
 // syncopated kick placement, ghost snares and short sampled-style drum punctuation.
 if(genre==='hipHop'&&soloType==='fullSolo'&&length>=4){
  const scale=(v:number)=>clamp(Math.round(v*(.82+power*.26)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.075)=>{
   const time=bar*4+step*.25;
   if(bar<0||bar>=length||time>=length*4)return;
   const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
   if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));
   else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
  };
  for(let bar=0;bar<length;bar++){
   const progress=bar/Math.max(1,length-1),arc=dramaturgyCurve(progress),phrase=bar%4;
   const energy=58+power*28+arc*15,variation=(bar+seed)%4;
   // Deep, syncopated kick: leave deliberate holes rather than a rock ostinato.
   const kicks=choose([[0,7,10],[0,6,11,14],[0,3,10,13],[0,8,11]],variation);
   kicks.forEach((st,i)=>put(bar,st,GM.kick,energy+(i===0?18:5),.11));
   // Boom-bap backbeat stays recognizable; ghost notes create the internal motion.
   [4,12].forEach(st=>put(bar,st,GM.snare,energy+17,.09));
   if(skill>.18){
    const ghosts=choose([[2,11],[2,7,11],[3,10,15],[1,6,11,14]],variation);
    ghosts.forEach(st=>put(bar,st,GM.snare,27+skill*27,.055));
   }
   // Closed hats carry a relaxed eighth-note grid; higher complexity adds selective 16ths.
   const hats=skill>.72?[0,2,4,6,8,10,12,14]:[0,4,8,12];
   hats.forEach((st,i)=>put(bar,st,GM.hat,energy-25+(i%2===0?5:-7),.055));
   if(skill>.48&&phrase%2===1)choose([[6,7],[14,15],[2,3]],variation).forEach(st=>put(bar,st,GM.hat,energy-19,.045));
   // Short fills are punctuation at phrase boundaries, not continuous tom rolls.
   if(phrase===3&&arc>.42&&skill>.35){
    choose([[10,14],[11,15],[8,12,15]],variation).forEach((st,i)=>put(bar,st,i===1?GM.lowTom:GM.rim,energy-5,.07));
    if(progress>.55)put(bar,15,GM.snare,energy+9,.07);
   }
   if(bar===0&&previousSection.toLowerCase().includes('chorus'))put(bar,15,GM.snare,energy+8,.07);
  }
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.5: Reggae — a pocket-first solo with One Drop, Rockers and Steppers phases.
 // The groove breathes between phrases; fills answer the pulse rather than turning into rock licks.
 if(genre==='reggae'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.80+power*.30)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.085)=>{
   const time=bar*4+step*.25;
   if(bar>=0&&bar<length&&time<length*4){
    const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
    if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));
    else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
   }
  };
  const kick=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.kick,v,.10));
  const rim=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.rim,v,.075));
  const snare=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.snare,v,.085));
  const hat=(bar:number,steps:number[],v:number)=>steps.forEach((st,i)=>put(bar,st,GM.hat,v+(i%2===0?3:-5),.065));
  const tomLine=(bar:number,steps:number[],v:number)=>{
   const voices=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom,GM.lowTom,GM.snare];
   steps.forEach((st,i)=>put(bar,st,voices[(i+Math.abs(seed))%voices.length],v+(i%4===0?7:0)-(i%4===3?4:0),.075));
  };
  const flam=(bar:number,step:number,pitch:number,v:number)=>{
   const time=bar*4+step*.25;
   if(time>.055&&time<length*4){const grace=time-.055;if(!out.some(n=>n.pitch===pitch&&Math.abs(n.time-grace)<.001))out.push({pitch,time:grace,duration:.035,velocity:scale(v-27)});put(bar,step,pitch,v,.09);}
  };
  const variation=Math.abs(seed)%4;
  const roots=drummerStyle==='oneDrop';
  const tight=drummerStyle==='tightReggae';
  const steppers=drummerStyle==='steppers';
  const rockers=drummerStyle==='rockers';
  const energyAt=(bar:number)=>43+dramaturgyCurve(bar/Math.max(1,length-1))*34+power*16;
  const phraseCount=Math.ceil((length-1)/4);
  for(let bar=0;bar<length-1;bar++){
   const phrase=bar%4,cycle=Math.floor(bar/4),progress=bar/Math.max(1,length-1),energy=energyAt(bar);
   const peak=progress>.68;
   // The first block is always rooted in One Drop; later blocks introduce Rockers and Steppers.
   const phase=cycle===0?0:cycle===1?1:cycle<Math.ceil(phraseCount*.72)?(cycle%2===0?1:0):2;
   const useSteppers=steppers||(!roots&&!tight&&(phase===2||rockers&&peak));
   const useRockers=rockers||(!roots&&!tight&&!steppers&&phase===1);
   // Keep the recognizable reggae pulse in every bar: rim/snare answers are dry and deliberate.
   if(phrase===0){
    if(useSteppers)kick(bar,[0,4,8,12],energy+13);
    else if(useRockers)kick(bar,variation===1?[0,6,8,14]:[0,8,12],energy+12);
    else kick(bar,[8],energy+12);
    rim(bar,[8],energy+14);hat(bar,[0,4,8,12],energy-18);
    if(cycle===0)put(bar,0,GM.crash,energy+7,.18);
   }else if(phrase===1){
    if(useSteppers)kick(bar,[0,4,8,12],energy+12);
    else if(useRockers)kick(bar,[0,8,14],energy+10);
    else kick(bar,[8],energy+10);
    rim(bar,[8],energy+13);hat(bar,[0,4,8,12,...(tight?[2,10]:[])],energy-19);
    if(skill>.48)snare(bar,[14],energy-13); // a light pickup, not a rock backbeat
   }else if(phrase===2){
    if(useSteppers)kick(bar,[0,4,8,12],energy+13);
    else if(useRockers)kick(bar,[0,6,8],energy+11);
    else kick(bar,variation===2?[8,14]:[8],energy+11);
    rim(bar,[8],energy+13);hat(bar,[0,4,8,12],energy-20);
    if(skill>.34){snare(bar,[6],energy-22);if(peak&&skill>.68)tomLine(bar,[14],energy-3);}
   }else{
    if(useSteppers)kick(bar,[0,4,8],energy+12);
    else kick(bar,[8],energy+10);
    rim(bar,[8],energy+12);hat(bar,[0,4,8,12],energy-20);
    // Four-bar call/response: short tom phrase, with space on beat one of the next bar.
    if(cycle===0)tomLine(bar,[12,14],energy-2);
    else if(skill>.25){
     const steps=skill>.76?[10,11,12,13,14,15]:skill>.48?[11,12,14,15]:[12,15];
     tomLine(bar,steps,energy+(peak?10:4));
     if(peak&&variation%2===0)flam(bar,14,GM.snare,energy+14);
    }
   }
   // A short breath in bar 8 and, for 32 bars, bar 24; the motif returns immediately after.
   if((bar===7||length>=32&&bar===23)&&!useSteppers){
    out.splice(0,out.length,...out.filter(n=>n.time<bar*4||n.time>=(bar+1)*4));
    kick(bar,[0],energy-2);rim(bar,[8],energy+2);hat(bar,[0,8],energy-22);
   }
   // The final build adds tom movement, not a continuous wall of snare notes.
   if(peak&&phrase===2&&skill>.55)tomLine(bar,[10,12,14],energy+7);
  }
  // Last bar is reserved for a single ensemble cadence; no notes spill after it.
  const last=length-1,final=clamp(112+power*14,1,127);
  put(last,0,GM.kick,final,.22);put(last,0,GM.snare,final-5,.22);
  if(previousSection.toLowerCase().includes('chorus')){rim(0,[14],76+power*14);put(0,15,GM.lowTom,82+power*14);}
  else if(previousSection.toLowerCase().includes('bridge')){put(0,12,GM.lowTom,72+power*15);flam(0,15,GM.snare,82+power*15);}
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.8: Ska Solo — bright offbeat drive, tight backbeat and melodic tom call/response.
 // The offbeat eighth-note lift stays present throughout; solo phrases develop around it.
 if(genre==='ska'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.82+power*.28)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.075)=>{
   const time=bar*4+step*.25;
   if(bar>=0&&bar<length&&time<length*4){
    const old=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
    if(old)old.velocity=Math.max(old.velocity,scale(velocity));
    else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
   }
  };
  const kick=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.kick,v,.10));
  const snare=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.snare,v,.085));
  const offbeat=(bar:number,v:number,open=false)=>[2,6,10,14].forEach((st,i)=>put(bar,st,open&&i===3?GM.openHat:GM.hat,v+(i%2===0?3:-3),.065));
  const tomPhrase=(bar:number,steps:number[],v:number,cycle:number)=>{
   const voices=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom,GM.snare,GM.lowTom];
   steps.forEach((st,i)=>put(bar,st,voices[(i+cycle+Math.abs(seed))%voices.length],v+(i%4===0?8:i%4===3?-5:0),.075));
  };
  const variation=Math.abs(seed)%4;
  for(let bar=0;bar<length;bar++){
   const phrase=bar%4,cycle=Math.floor(bar/4),progress=bar/Math.max(1,length-1);
   const energy=48+dramaturgyCurve(progress)*34+power*17;
   const lift=phrase===0||phrase===2;
   // Ska pulse: offbeat hats never disappear, even while the hands move around the kit.
   if(phrase===0)kick(bar,variation%2===0?[0,8]:[0,6,8],energy+12);
   else if(phrase===1)kick(bar,[0,8,14],energy+9);
   else if(phrase===2)kick(bar,variation%2===1?[0,6,8,14]:[0,8],energy+11);
   else kick(bar,[0,8,12],energy+9);
   snare(bar,phrase===3?[4,12,15]:[4,12],energy+10);
   offbeat(bar,energy-15,cycle%2===1);
   if(bar===0||phrase===0&&cycle>0)put(bar,0,GM.crash,energy+7,.16);
   // Short melodic answers: sparse early, increasingly animated in the middle and peak.
   if(phrase===1&&cycle>0&&skill>.28)tomPhrase(bar,skill>.72?[10,11,12,14]:[10,12,14],energy-4,cycle);
   if(phrase===2&&progress>.28&&skill>.4)tomPhrase(bar,skill>.78?[6,8,10,12,14]:[8,11,14],energy+1,cycle+1);
   if(phrase===3){
    if(cycle===0)tomPhrase(bar,[12,14,15],energy+3,cycle);
    else if(skill>.25)tomPhrase(bar,skill>.72?[10,11,12,13,14,15]:[11,12,14,15],energy+(progress>.65?12:6),cycle+variation);
    if(progress>.65&&skill>.62)snare(bar,[14,15],energy+9);
   }
   // A restrained ska-style handclap/rim colour on selected upbeat answers.
   if(lift&&cycle>0&&variation%2===0)put(bar,6,GM.rim,energy-18,.06);
  }
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.4: Punk Raw Energy — a dedicated, phrase-led punk solo.
 // The engine blends classic punk drive, melodic-punk hand technique and hardcore bursts.
 // Eight-bar material is developed across 16/32 bars; stop-start breaks and flam-led fills
 // create contrast without losing the relentless eighth-note identity.
 if(genre==='punk'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.78+power*.34)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.085)=>{
   const time=bar*4+step*.25;
   if(bar>=0&&bar<length&&time<length*4){
    const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
    if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));
    else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
   }
  };
  const kick=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.kick,v,.10));
  const snare=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.snare,v,.085));
  const cymbal=(bar:number,steps:number[],pitch:number,v:number)=>steps.forEach((st,i)=>put(bar,st,pitch,v+(i%2===0?3:-5),.075));
  const tomLine=(bar:number,steps:number[],v:number)=>{
   const voices=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom,GM.snare,GM.lowTom];
   steps.forEach((st,i)=>put(bar,st,voices[(i+Math.abs(seed))%voices.length],v+(i%4===0?7:0)-(i%4===3?4:0),.075));
  };
  const flam=(bar:number,step:number,pitch:number,v:number)=>{
   const main=bar*4+step*.25;
   if(main>.055&&main<length*4){
    const grace=main-.055;
    if(!out.some(n=>n.pitch===pitch&&Math.abs(n.time-grace)<.001))out.push({pitch,time:grace,duration:.035,velocity:scale(v-28)});
    put(bar,step,pitch,v,.095);
   }
  };
  const fill=(bar:number,kind:number,e:number)=>{
   if(kind===0){snare(bar,[12,13,14,15],e+8);}
   else if(kind===1){flam(bar,12,GM.snare,e+19);tomLine(bar,[13,14,15],e+11);}
   else if(kind===2){tomLine(bar,[10,11,12,13,14,15],e+9);}
   else {snare(bar,[12,14],e+10);flam(bar,15,GM.lowTom,e+21);}
  };
  const variation=Math.abs(seed)%4;
  const profile=drummerStyle;
  const straight=profile==='straightEighths';
  const heavy=profile==='heavyBackbeat'||profile==='powerSwing';
  const precise=profile==='precisionFills';
  const energyAt=(bar:number)=>46+dramaturgyCurve(bar/Math.max(1,length-1))*34+power*17;
  for(let bar=0;bar<length-1;bar++){
   const phrase=bar%4,cycle=Math.floor(bar/4),eight=cycle%2===0?[0,2,4,6,8,10,12,14]:[0,2,4,6,8,10,12,14];
   const e=energyAt(bar),progress=bar/Math.max(1,length-1),late=progress>.52;
   const stop=(phrase===3&&cycle===1)||(length>=32&&phrase===3&&cycle===5);
   if(stop){
    // One-bar stop-and-go break: retain a single count-in and leave deliberate air.
    kick(bar,[0],e+5);snare(bar,[4],e+3);put(bar,8,GM.crash,e+9,.18);
    if(variation%2===0)put(bar,14,GM.hat,e-20,.06);
    continue;
   }
   // Persistent punk eighth-note identity, with seed-controlled kick variations.
   const kickShape=heavy?[[0,2,4,6,8,10,12,14],[0,4,6,8,10,12,14],[0,2,6,8,12,14],[0,2,4,8,10,12,14]]
    :straight?[[0,4,8,12],[0,2,4,8,12],[0,4,6,8,12,14],[0,4,8,10,12]]
    :[[0,2,4,6,8,10,12,14],[0,4,6,8,10,12,14],[0,2,6,8,12,14],[0,2,4,8,10,12,14]];
   const k=kickShape[(variation+cycle+phrase)%kickShape.length];
   if(phrase===0){
    put(bar,0,GM.crash,e+19,.22);kick(bar,k,e+15);snare(bar,[4,12],e+17);cymbal(bar,eight,GM.hat,e-17);
   }else if(phrase===1){
    kick(bar,k.filter((_,i)=>i%2===0),e+13);snare(bar,[4,12],e+16);cymbal(bar,eight,late?GM.ride:GM.hat,e-19);
    if(late)put(bar,15,GM.midTom,e+1);
   }else if(phrase===2){
    kick(bar,variation===2?[0,6,8,14]:[0,4,8,12],e+14);snare(bar,[4,12],e+16);
    if(cycle>=1){put(bar,10,GM.snare,e-15);put(bar,14,GM.lowTom,e+2);}
    cymbal(bar,eight,GM.hat,e-20);
   }else{
    kick(bar,[0,8],e+13);snare(bar,[4],e+13);
    if(cycle===0){tomLine(bar,[10,12,14,15],e+5);}
    else fill(bar,(cycle+variation+(precise?1:0))%4,e);
    if(late)put(bar,0,GM.crash,e+8,.18);
   }
   // Melodic-punk handwork: short doubles/rolls, never a bar-long exercise.
   if(cycle>=1&&phrase===1&&complexity>38){
    const density=complexity>76?[10,11,12,13]:complexity>52?[10,12,13]:[12,14];
    snare(bar,density,e+(heavy?12:7));
   }
   // Hardcore accents enter only in the final half of the arc.
   if(late&&phrase===2&&((bar+variation)%3===0))flam(bar,12,GM.snare,e+19);
   if(late&&phrase===0&&cycle%2===0)put(bar,8,GM.crash,e+8,.18);
  }
  // A short pickup into the final bar, then a decisive shared downbeat and silence.
  if(length>=8){const lead=length-2,e=energyAt(lead);flam(lead,12,GM.snare,e+20);tomLine(lead,[13,14,15],e+13);}
  const last=length-1,final=clamp(116+power*11,1,127);
  put(last,0,GM.kick,final,.22);put(last,0,GM.snare,final-3,.22);
  if(previousSection.toLowerCase().includes('chorus')){flam(0,14,GM.snare,78+power*17);put(0,15,GM.lowTom,84+power*15);}
  else if(previousSection.toLowerCase().includes('bridge')){put(0,12,GM.lowTom,76+power*15);flam(0,15,GM.snare,84+power*17);}
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.3: Alternative Rock — broken motifs, dynamic drops, flam accents and phrase fills.
 // The solo alternates sparse, tense statements with explosive answers. Fills are composed
 // as phrase punctuation; flam grace notes lead into selected accented snare/tom hits.
 if(genre==='alternativeRock'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.76+power*.38)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.085)=>{
   const time=bar*4+step*.25;
   if(bar<length&&time<length*4){
    const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
    if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));
    else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
   }
  };
  const kick=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.kick,v,.10));
  const snare=(bar:number,steps:number[],v:number)=>steps.forEach(st=>put(bar,st,GM.snare,v,.09));
  const toms=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom];
  const tomLine=(bar:number,steps:number[],v:number)=>steps.forEach((st,i)=>put(bar,st,toms[(i+Math.floor(seed/5))%toms.length],v+(i%4===0?8:i%4===3?-5:0),.075));
  const flam=(bar:number,step:number,pitch:number,v:number)=>{
   const main=bar*4+step*.25;
   if(main>.055&&main<length*4){
    const grace=main-.055;
    if(!out.some(n=>n.pitch===pitch&&Math.abs(n.time-grace)<.001))out.push({pitch,time:grace,duration:.035,velocity:scale(v-27)});
    put(bar,step,pitch,v,.10);
   }
  };
  const fill=(bar:number,kind:number,energy:number)=>{
   // Four distinct fill shapes: displaced snare, tom answer, flam-led burst, and stop-start hit.
   if(kind===0){snare(bar,[12,14],energy+7);tomLine(bar,[15],energy+12);}
   else if(kind===1){flam(bar,12,GM.snare,energy+18);tomLine(bar,[13,14,15],energy+9);}
   else if(kind===2){tomLine(bar,[12,13,14],energy+11);flam(bar,15,GM.lowTom,energy+20);}
   else {snare(bar,[12],energy+12);tomLine(bar,[14],energy+15);flam(bar,15,GM.snare,energy+22);}
  };
  const variation=Math.abs(seed)%4;
  const energyAt=(bar:number)=>46+dramaturgyCurve(bar/Math.max(1,length-1))*31+power*17;
  for(let bar=0;bar<length-1;bar++){
   const phrase=bar%4,cycle=Math.floor(bar/4),energy=energyAt(bar),progress=bar/Math.max(1,length-1);
   const drop=(cycle===1&&phrase===0)||(length>=16&&cycle===Math.floor(length/8)*2&&phrase===0);
   // A two-bar broken-backbeat motif: the kick/snare identity returns with displaced accents.
   if(drop){
    // Deliberate dynamic drop: leave air, keep only a few low-velocity anchor notes.
    kick(bar,[0],energy-10);put(bar,8,GM.rim,energy-13);put(bar,12,GM.snare,energy-18);
    if(bar%2===0)put(bar,14,GM.hat,energy-24);
    continue;
   }
   if(phrase===0){
    put(bar,0,GM.crash,energy+18,.24);kick(bar,variation===1&&cycle>0?[0,6,8]:[0,8],energy+16);
    snare(bar,[4,12],energy+17);[0,4,8,12].forEach(st=>put(bar,st,GM.hat,energy-18,.07));
   }else if(phrase===1){
    kick(bar,variation===2?[0,7,10]:[0,8],energy+13);snare(bar,[4,12],energy+16);
    put(bar,6,GM.hat,energy-16);put(bar,14,GM.openHat,energy-9);
    if(cycle>=1)put(bar,15,GM.midTom,energy+3);
   }else if(phrase===2){
    // Motif is fragmented: a gap on beat two, then a syncopated answer.
    kick(bar,[0,10],energy+15);snare(bar,[6,12],energy+14);
    put(bar,2,GM.hat,energy-17);put(bar,8,GM.hat,energy-17);put(bar,14,GM.openHat,energy-8);
    if(cycle>=2)flam(bar,12,GM.snare,energy+14);
   }else{
    // Phrase-ending fills are shaped by the energy arc, not randomly scattered.
    kick(bar,[0],energy+13);snare(bar,[4],energy+12);
    if(cycle===0){tomLine(bar,[10,14],energy+3);}
    else fill(bar,(cycle+variation)%4,energy);
   }
   // A few controlled flam accents in the middle and final development blocks.
   if(cycle>=1&&phrase===2&&((bar+variation)%3===0))flam(bar,6,GM.snare,energy+13);
   // Short cymbal punctuations; avoid washing out the broken groove.
   if(progress>.45&&phrase===0&&cycle%2===0)put(bar,8,GM.crash,energy+5,.18);
  }
  // A final composed fill leads into a decisive last-bar downbeat.
  if(length>=8){const lead=length-2,e=energyAt(lead);flam(lead,12,GM.snare,e+19);tomLine(lead,[13,14,15],e+13);}
  const last=length-1,final=clamp(113+power*14,1,127);
  put(last,0,GM.kick,final,.22);put(last,0,GM.snare,final-4,.22);
  if(previousSection.toLowerCase().includes('chorus')){flam(0,14,GM.snare,76+power*18);put(0,15,GM.lowTom,82+power*17);}
  else if(previousSection.toLowerCase().includes('bridge')){put(0,12,GM.lowTom,74+power*16);flam(0,15,GM.snare,82+power*18);}
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.1: motif-led Classic Rock Hybrid solo.
 // One compact kick/snare identity is stated, answered, moved to the toms,
 // then progressively intensified. Fills are phrase endings, never random inserts.
 if(genre==='classicRock'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.78+power*.34)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.085)=>{
   const time=bar*4+step*.25;
   if(bar<length&&time<length*4){const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});}
  };
  const cymbal=(bar:number,steps:number[],velocity:number)=>steps.forEach(step=>put(bar,step,GM.ride,velocity,.09));
  const kick=(bar:number,steps:number[],velocity:number)=>steps.forEach(step=>put(bar,step,GM.kick,velocity,.10));
  const snare=(bar:number,steps:number[],velocity:number)=>steps.forEach(step=>put(bar,step,GM.snare,velocity,.09));
  const tomLine=(bar:number,steps:number[],voices:number[],velocity:number)=>steps.forEach((step,i)=>put(bar,step,voices[i%voices.length],velocity+(i%4===0?7:0)-(i%4===3?4:0),.075));
  const variation=(seed+Math.floor(seed/3))%3;
  const heavy=drummerStyle==='heavyBackbeat'||drummerStyle==='powerSwing';
  const rolling=drummerStyle==='rollingToms'||drummerStyle==='dynamicToms';
  const precise=drummerStyle==='precisionFills';
  const toms=rolling?[GM.lowTom,GM.midTom,GM.hiTom,GM.midTom]:[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom];
  const energyAt=(bar:number)=>48+dramaturgyCurve(bar/Math.max(1,length-1))*30+power*16;

  for(let bar=0;bar<length-1;bar++){
   const phrase=bar%4,section=Math.floor(bar/4),energy=energyAt(bar);
   // The opening two-bar motif: kick on the phrase anchors, snare on beats 2 and 4.
   // Bar two answers the same contour with one small rhythmic displacement.
   if(section===0&&phrase===0){
    put(bar,0,GM.crash,energy+25,.28);kick(bar,[0,8],energy+19);snare(bar,[4,12],energy+18);
    cymbal(bar,[0,4,8,12],energy-17);
   }else if(section===0&&phrase===1){
    kick(bar,variation===1?[0,7,8]:[0,8],energy+16);snare(bar,[4,12],energy+17);
    put(bar,14,GM.midTom,energy-2);put(bar,15,GM.lowTom,energy+3);
   }else if(section===0&&phrase===2){
    // Motif is transferred to the toms, while the snare keeps its identity.
    kick(bar,[0,8],energy+15);snare(bar,[4,12],energy+16);
    tomLine(bar,[10,14],toms.slice(0,2),energy-1);
    if(section>=1)put(bar,15,GM.lowTom,energy+5);
   }else if(section===0&&phrase===3){
    // A short answer, with space before the next statement.
    kick(bar,[0],energy+13);snare(bar,[4],energy+13);
    const steps=skill>.62?[8,10,12,14,15]:[8,12,14];
    tomLine(bar,steps,toms,energy+4);
    if(section>=2)put(bar,15,GM.snare,energy+11);
   }

   // Second four-bar cycle: recognizable reprise, changed orchestration and accents.
   if(section===1){
    if(phrase===0){put(bar,0,GM.crash,energy+18,.24);kick(bar,[0,8],energy+17);snare(bar,[4,12],energy+17);cymbal(bar,[0,8],energy-15);}
    if(phrase===1){kick(bar,[0,6,8],energy+15);snare(bar,[4,12],energy+16);tomLine(bar,[14],toms.slice(1,3),energy+2);}
    if(phrase===2){kick(bar,[0,8],energy+17);snare(bar,[4,10,12],energy+16);tomLine(bar,[14],toms.slice(0,2),energy+4);}
    if(phrase===3){snare(bar,[4],energy+13);tomLine(bar,skill>.55?[8,10,12,14]:[8,12,14],toms,energy+7);}
   }

   // Third cycle: the original motif is stretched into busier call-and-response phrases.
   if(section===2){
    if(phrase===0){put(bar,0,GM.crash,energy+17,.22);kick(bar,[0,8],energy+17);snare(bar,[4,12],energy+17);}
    if(phrase===1){kick(bar,[0,8],energy+16);snare(bar,[4,10,12],energy+18);tomLine(bar,[14,15],toms.slice(0,2),energy+5);}
    if(phrase===2){
     kick(bar,[0,8],energy+16);
     const count=skill>.68?8:skill>.38?6:4;
     const steps=Array.from({length:count},(_,i)=>8+i*(8/count));
     tomLine(bar,steps,precise?[GM.snare,GM.hiTom,GM.snare,GM.midTom]:[GM.snare,...toms.slice(0,3)],energy+8);
    }
    if(phrase===3){kick(bar,[0],energy+15);tomLine(bar,skill>.55?[8,9,10,11,12,13,14,15]:[8,10,12,14],toms,energy+10);}
   }

   // Fourth cycle is the climax: short, controlled bursts, not an uninterrupted roll.
   if(section>=3){
    if(phrase===0){put(bar,0,GM.crash,energy+20,.24);kick(bar,[0,8],energy+18);snare(bar,[4,12],energy+19);}
    if(phrase===1){kick(bar,[0,8],energy+17);snare(bar,[4,12],energy+20);tomLine(bar,[10,12,14,15],toms,energy+10);}
    if(phrase===2){
     kick(bar,[0,8],energy+18);
     const steps=skill>.55?[4,5,6,7,8,9,10,11,12,13,14,15]:[4,6,8,10,12,14];
     tomLine(bar,steps,precise?[GM.snare,GM.hiTom,GM.snare,GM.midTom]:[GM.snare,...toms.slice(0,3)],energy+13);
    }
    if(phrase===3){tomLine(bar,[8,9,10,11,12,13,14,15],toms,energy+15);put(bar,15,GM.snare,energy+22);}
   }

   // A compact hybrid flourish every four-bar phrase; intensity controls its density.
   if(phrase===3&&section>=1&&skill>.25){
    const steps=skill>.72?[12,13,14,15]:skill>.42?[12,14,15]:[12,15];
    const voices=rolling?[GM.lowTom,GM.midTom,GM.hiTom,GM.snare]:[GM.snare,GM.hiTom,GM.midTom,GM.lowTom];
    tomLine(bar,steps,voices,energy+9);
   }
   if(heavy&&phrase===0&&section>0)kick(bar,[0],energy+22);
  }

  // Final bar: a decisive shared downbeat, then silence. This gives the solo a real ending.
  const last=length-1,finalVelocity=clamp(112+power*15,1,127);
  put(last,0,GM.kick,finalVelocity,.22);put(last,0,GM.snare,finalVelocity-3,.22);
  // A small pickup into the solo only; no extra ending notes after the final downbeat.
  if(length>=4){
   if(previousSection.toLowerCase().includes('chorus')){put(0,14,GM.snare,72+power*18);put(0,15,GM.lowTom,78+power*18);}
   else if(previousSection.toLowerCase().includes('bridge')){put(0,12,GM.lowTom,72+power*18);put(0,15,GM.midTom,78+power*18);}
  }
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 // Version 0.4.2: Blues Rock gets its own motif-led solo language.
 // A swung ride ostinato anchors the groove; a compact kick/snare motif is
 // repeated, answered by toms, developed into short shuffle-based phrases,
 // then brought back for a clear blues-rock cadence.
 if(genre==='bluesRock'&&soloType==='fullSolo'&&length>=4){
  const scale=(n:number)=>clamp(Math.round(n*(.80+power*.30)),1,127);
  const put=(bar:number,step:number,pitch:number,velocity:number,duration=.085)=>{
   const time=bar*4+step*.25;
   if(bar<length&&time<length*4){
    const existing=out.find(n=>n.pitch===pitch&&Math.abs(n.time-time)<1e-9);
    if(existing)existing.velocity=Math.max(existing.velocity,scale(velocity));
    else out.push({pitch,time,duration:Math.min(duration,length*4-time),velocity:scale(velocity)});
   }
  };
  const line=(bar:number,steps:number[],voices:number[],velocity:number)=>steps.forEach((step,i)=>put(bar,step,voices[i%voices.length],velocity+(i%3===0?6:i%3===2?-3:0)));
  const kick=(bar:number,steps:number[],v:number)=>steps.forEach(step=>put(bar,step,GM.kick,v,.10));
  const snare=(bar:number,steps:number[],v:number)=>steps.forEach(step=>put(bar,step,GM.snare,v,.085));
  const ride=(bar:number,v:number)=>[0,3,4,7,8,11,12,15].forEach((step,i)=>put(bar,step,GM.ride,v+(i%2===0?4:-7),.075));
  const cycleCount=Math.ceil((length-1)/4);
  const toms=drummerStyle==='rollingToms'||drummerStyle==='dynamicToms'
   ?[GM.lowTom,GM.midTom,GM.hiTom,GM.midTom]
   :[GM.midTom,GM.lowTom,GM.midTom,GM.hiTom];
  const variation=Math.abs(seed)%3;
  const energyAt=(bar:number)=>50+dramaturgyCurve(bar/Math.max(1,length-1))*25+power*15;
  for(let bar=0;bar<length-1;bar++){
   const phrase=bar%4,cycle=Math.floor(bar/4),cycleProgress=cycle/Math.max(1,cycleCount-1);
   const energy=energyAt(bar),density=skill*(.55+cycleProgress*.45);
   // The same swung ride figure holds the pocket through the whole solo.
   ride(bar,energy-18);
   if(phrase===0){
    // Statement: a recognizable two-beat kick/snare blues motif.
    kick(bar,variation===1&&cycle>0?[0,7,8]:[0,8],energy+13);
    snare(bar,[4,12],energy+15);
    if(cycle===0)put(bar,0,GM.crash,energy+17,.25);
    else if(cycle%2===0&&cycleProgress>.35)put(bar,0,GM.crash,energy+10,.20);
   }else if(phrase===1){
    // Answer: keep the backbeat, shift one bass-drum pickup and add a short tom reply.
    kick(bar,variation===2?[0,6,8]:[0,8],energy+11);
    snare(bar,[4,12],energy+14);
    if(density>.22)line(bar,[10,14],toms.slice(0,2),energy-3);
   }else if(phrase===2){
    // Development: ghosted snare notes and a low-tom answer, with space around them.
    kick(bar,cycle%2===0?[0,8,14]:[0,6,8],energy+12);
    snare(bar,[4,12],energy+14);
    if(density>.28)snare(bar,[10],energy-25);
    if(density>.30)line(bar,[8,11,14],toms.slice(0,3),energy+1);
   }else{
    // Turnaround: a compact shuffle fill, never a continuous roll.
    kick(bar,[0],energy+10);
    snare(bar,[4],energy+12);
    if(density>.20){
     const steps=density>.72?[11,12,13,14,15]:density>.42?[12,14,15]:[12,15];
     line(bar,steps,toms,energy+5);
    }
    if(cycleProgress>.45)put(bar,15,GM.snare,energy+8);
   }
   // Every second phrase gets a small blues-style punctuation, not a new unrelated lick.
   if(phrase===2&&cycleProgress>.25&&density>.5)put(bar,14,GM.openHat,energy-10,.10);
  }
  // A final, unmistakable ensemble hit closes the solo; no fill follows it.
  const last=length-1,finalVelocity=clamp(110+power*16,1,127);
  put(last,0,GM.kick,finalVelocity,.22);
  put(last,0,GM.snare,finalVelocity-4,.22);
  // Pickup is deliberately short and bluesy, and only responds to the prior section.
  if(previousSection.toLowerCase().includes('chorus')){put(0,14,GM.snare,68+power*18);put(0,15,GM.lowTom,74+power*18);}
  else if(previousSection.toLowerCase().includes('bridge')){put(0,12,GM.lowTom,68+power*18);put(0,15,GM.midTom,74+power*18);}
  removeFinalCrash();
  continueFullSoloThroughLastBar();
  removeFinalCrash();
  return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 }
 const phraseEnd=(bar:number)=>bar%4===3||bar===length-1;
 for(let bar=0;bar<length;bar++){
  const progress=length===1?1:bar/(length-1),arcProgress=soloType==='soloOutro'?progress:dramaturgyCurve(progress),phrase=bar%4,variant=(bar+seed)%4;
  const build=soloType==='drumBreak'?.28+power*.28:soloType==='soloOutro'?.48+progress*.42:.20+arcProgress*(.40+power*.34);
  const base=clamp(45+build*61,1,119),density=soloType==='drumBreak'?skill*.62:skill*(.62+arcProgress*.38);
  const trading=soloType==='tradingFours',timekeeping=trading&&Math.floor(bar/4)%2===1;
  if(timekeeping){
   if(genre==='bluesRock'){
    add(bar,[0,4,8,12],GM.ride,base-18);add(bar,[4,12],GM.hat,base-32);
   }else if(genre==='funk'){
    add(bar,[0,7,10],GM.kick,base-18);add(bar,[4,12],GM.snare,base-18);add(bar,[2,6,10,14],GM.hat,base-30);
   }else if(genre==='reggae'){
    add(bar,[8],GM.kick,base-16);add(bar,[8],GM.rim,base-12);add(bar,[2,6,10,14],GM.hat,base-28);
   }else if(genre==='ska'){
    add(bar,[0,8],GM.kick,base-16);add(bar,[4,12],GM.snare,base-16);add(bar,[2,6,10,14],GM.openHat,base-24);
   }else{
    add(bar,[0,8],GM.kick,base-18);add(bar,[4,12],GM.snare,base-18);add(bar,[0,4,8,12],GM.hat,base-32);
   }
   continue;
  }

  if(personality==='rockHardRock'||personality==='punkDrive'||personality==='alternativeRock'){
   // Phrase-led rock solos: establish a motif, answer it, leave space, then build to a clear cadence.
   if(genre==='alternativeRock'){
    const arc=soloType==='drumBreak'?.32+power*.2:.18+arcProgress*(.42+power*.25);
    const motif=choose([[0,7,10],[0,5,8,13],[0,6,11],[0,4,9]],Math.floor((bar%4)/2)+(seed%3));
    const profile=drummerStyle;
    const offbeat=profile==='offbeatSka'||profile==='brokenBeats';
    const heavy=profile==='heavyBackbeat'||profile==='powerSwing';
    const rolling=profile==='rollingToms'||profile==='dynamicToms';
    const precision=profile==='precisionFills';
    // Two-bar call/response; bars 4 and 8 deliberately breathe before resolving.
    const kick=bar%4===0?motif:bar%4===1?motif.filter((_,i)=>i%2===0):bar%4===2?choose([[0,8],[0,6,10],[0,8,14]],variant):[0,8];
    add(bar,kick,GM.kick,base+(heavy?8:2));
    const snare=offbeat?choose([[4,12],[4,11],[3,12]],variant):heavy?[4,12]:choose([[4,12],[4,11],[4,13]],variant);
    add(bar,snare,GM.snare,base+(heavy?9:4));
    // Restrained answer motifs; avoid stacking several tom lanes on the same subdivision.
    if(bar%4===1&&density>.22)add(bar,choose([[10,14],[8,12,14],[11,15]],variant),GM.midTom,base-12);
    if(bar%4===2&&density>.34)add(bar,rolling?[6,8,10,12,14]:choose([[8,12],[10,14],[7,11,14]],variant),GM.lowTom,base-8);
    if(bar%4===3){
      if(density>.25)add(bar,precision?[12,14,15]:choose([[12,15],[11,14,15],[13,15]],variant),GM.snare,base+7);
      if(progress>.45)add(bar,[0],GM.crash,base+5);
    }
    if(offbeat&&density>.5&&bar%4===2)add(bar,[6,14],GM.rim,base-15,.07);
    // High development increases phrase contrast and accent strength, not constant note density.
    if(arc>.62&&bar%4===2)add(bar,[15],GM.lowTom,base-4);
    if(bar===0||bar%4===0&&progress>.5)add(bar,[0],GM.crash,base+5);
   }else if(genre==='punk'){
    // Punk: relentless eighth-note drive, blunt backbeat and short, explosive endings.
    const kick=choose([[0,2,4,6,8,10,12,14],[0,4,6,8,10,12,14],[0,2,6,8,12,14]],variant);
    add(bar,kick,GM.kick,base+9);add(bar,[4,12],GM.snare,base+10);
    if(density>.32)add(bar,choose([[12,14,15],[8,12,14,15],[10,13,14,15]],variant),GM.snare,base+3);
    if(density>.48&&phrase>=2)add(bar,choose([[8,12,14],[10,12,15],[7,11,14,15]],variant),GM.lowTom,base-8);
    if(bar===0||phrase===0&&progress>.3)add(bar,[0],GM.crash,base+8);
   }else{
    // Rock family expansion: classic rock stays spacious and melodic; hard-rock voicings
    // become heavier through the selected drummer profile without changing the GUI genre list.
    const hard=drummerStyle==='heavyBackbeat'||drummerStyle==='powerSwing';
    const rolling=drummerStyle==='rollingToms'||drummerStyle==='dynamicToms';
    const precise=drummerStyle==='precisionFills';
    const straight=drummerStyle==='straightEighths';
    const classicKick=[[0,8],[0,4,8],[0,6,8,14],[0,8,12]];
    const hardKick=[[0,4,8,12],[0,6,8,14],[0,4,8,10,12],[0,8,12,14]];
    const kick=choose(hard?hardKick:classicKick,variant);
    add(bar,kick,GM.kick,base+(hard?13:8));
    add(bar,hard?[4,12]:[4,12],GM.snare,base+(hard?13:9));
    // A steady eighth-note cymbal pulse gives the rock solo a recognizable time bed;
    // hard-rock profiles shift selected accents to the ride for a wider, heavier sound.
    if(density>.18){
     if(hard||straight)add(bar,[0,2,4,6,8,10,12,14],hard?GM.ride:GM.hat,base-(hard?18:22));
     else if(bar%4===0||bar%4===1)add(bar,[0,4,8,12],GM.ride,base-24);
    }
    const midShapes=hard?[[8,12,14,15],[6,10,12,14,15],[8,11,14,15],[4,8,12,14,15]]:[[8,12,14],[6,10,12,14],[8,11,14,15],[4,8,12,15]];
    if(density>(hard?.27:.34))add(bar,choose(midShapes,variant+(rolling?1:0)),GM.midTom,base-(hard?2:6));
    if(density>.48&&phrase>=2)add(bar,rolling?[8,10,12,14,15]:choose([[12,14,15],[10,13,15],[8,12,14,15]],variant),GM.lowTom,base-(hard?0:3));
    if(phraseEnd(bar)&&density>.38)add(bar,precise?[13,15]:hard?[10,12,14,15]:[12,14,15],GM.snare,base+(hard?9:5));
    // Crash punctuation is phrase-led, not on every bar; the final phrase earns the strongest hit.
    if(bar===0||phrase===0&&progress>.4)add(bar,[0],GM.crash,base+(hard?12:8));
    if(hard&&phraseEnd(bar)&&progress>.55)add(bar,[0],GM.crash,base+14);
   }
  }else if(personality==='bluesRock'){
   // Blues Rock: shuffle-inflected ride pulse, conversational snare and bluesy tom answers.
   add(bar,[0,4,8,12],GM.ride,base-12);
   if(density>.25)add(bar,[2,6,10,14],GM.ride,base-25);
   add(bar,choose([[4,12],[3,7,12],[4,11,12],[2,7,12]],variant),GM.snare,base+1);
   add(bar,choose([[0,6,8,14],[0,4,10,12],[2,6,8,14],[0,7,10,15]],variant),GM.kick,base+2);
   if(density>.3)add(bar,choose([[8,11,14],[10,12,15],[7,11,14,15],[8,12,14]],variant),GM.lowTom,base-8);
   if(density>.48&&phrase>=2)add(bar,[12,14,15],GM.snare,base+4);
   if(phraseEnd(bar)&&density>.38)add(bar,[14,15],GM.lowTom,base-2);
  }else if(personality==='funkSoul'){
   // Funk solo: keep the pocket alive while the solo voice develops in four-bar call/response phrases.
   // The kick stays syncopated, the backbeat remains legible, and quiet snare ghosts create the funk grid.
   const kickCells=[[0,6,11],[0,3,8,14],[2,7,10,15],[0,5,9,12]];
   const ghostCells=[[2,6,10,14],[1,5,9,13],[3,7,11,15],[2,5,10,13]];
   const answerCells=[[3,7,11,15],[1,6,9,14],[2,5,10,13],[3,6,11,14]];
   const phraseStage=Math.floor(bar/4)%4;
   const kickShape=choose(kickCells,variant+Math.floor(bar/4));
   add(bar,kickShape,GM.kick,base+5);
   add(bar,[4,12],GM.snare,base+2);
   add(bar,choose(ghostCells,variant+phrase),GM.snare,Math.max(18,base-48),.055);
   // Closed hi-hat sixteenths are intentionally dynamic, not a constant loud machine-gun roll.
   const hatShape=phraseStage===0?[0,4,8,12]:phraseStage===1?[0,2,4,6,8,10,12,14]:phraseStage===2?[0,1,4,6,8,9,12,14]:[0,2,4,6,8,10,12,14];
   add(bar,hatShape,GM.hat,base-30,.065);
   if(phraseStage===1||phraseStage===3)add(bar,[7,15],GM.openHat,base-18,.08);
   // Funk call-and-response: toms answer the snare, then become more linear near the peak.
   if(phraseStage===0)add(bar,choose([[10,14],[11,15],[8,14]],variant),GM.midTom,base-17);
   else if(phraseStage===1)add(bar,choose([[3,7,11],[2,6,10,14],[5,9,13]],variant),GM.lowTom,base-15);
   else if(phraseStage===2)add(bar,choose([[3,6,11,14],[1,5,9,13],[2,7,10,15]],variant),GM.midTom,base-12);
   else add(bar,choose([[8,10,12,14,15],[7,10,12,14,15],[9,11,13,15]],variant),GM.snare,base-4);
   if(density>.42)add(bar,[6,14],GM.rim,base-32,.055);
   if(phraseEnd(bar)&&density>.35)add(bar,[11,14,15],GM.snare,base+2);
  }else if(personality==='popHipHop'){
   // Short, memorable break motifs; leave air and return cleanly to the main groove.
   const motif=choose([[0,10],[0,7,10],[0,6,11,14],[0,8,14]],variant);
   add(bar,motif,GM.kick,base+5);add(bar,[4,12],GM.snare,base+2);
   if(density>.35)add(bar,choose([[10,14],[8,11,15],[9,13,15]],variant),GM.snare,base-13);
   if(density>.48)add(bar,choose([[0,6,12],[3,7,11],[8,12,15]],variant),GM.lowTom,base-13);
   if(soloType==='drumBreak'&&length>1&&bar===length-1)add(bar,[8,12,14,15],GM.snare,base+3);
   if(phraseEnd(bar)&&density>.55)add(bar,[14],GM.crash,base-2);
  }else if(genre==='reggae'){
   // Preserve the one-drop centre; tom phrases answer rather than replace the pulse.
   add(bar,[8],GM.kick,base+1);add(bar,[8],GM.rim,base-2);
   add(bar,choose([[3,7,11,15],[5,9,13],[2,6,10,14],[3,6,11,14]],variant),GM.lowTom,base-10);
   if(density>.5)add(bar,[12,14],GM.snare,base-17);
   if(phraseEnd(bar))add(bar,[14,15],GM.lowTom,base-3);
  }else{
   // Ska: offbeat lift and brisk, compact tom/snare exchanges.
   add(bar,[0,8],GM.kick,base);add(bar,[4,12],GM.snare,base-1);add(bar,[2,6,10,14],GM.openHat,base-17);
   add(bar,choose([[3,7,11,15],[1,5,9,13],[2,6,10,14],[3,6,11,14]],variant),GM.midTom,base-9);
   if(density>.55)add(bar,[8,12,14,15],GM.lowTom,base-3);
   if(phraseEnd(bar))add(bar,[14,15],GM.snare,base-2);
  }
 }
 // Solo Intelligence: introduce a small, genre-aware rudiment vocabulary as musical
 // phrases rather than continuous exercise-like rolls. The phrase positions are
 // deterministic for a seed, while the vocabulary changes with the genre.
 if(soloType==='fullSolo'&&length>=4){
  const rudiments=[
   {name:'single',steps:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]},
   {name:'double',steps:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]},
   {name:'paradiddle',steps:[0,2,4,6,8,10,12,14]},
   {name:'flam',steps:[0,4,8,12]},
   {name:'drag',steps:[2,6,10,14]}
  ];
  const rudimentFor=(phraseIndex:number)=>{
   const pools:Record<string,string[]>={
    rockHardRock:['single','double','paradiddle','flam'],punkDrive:['single','double','single','paradiddle'],
    alternativeRock:['paradiddle','flam','single','drag'],bluesRock:['shuffle','drag','flam','paradiddle'],
    funkSoul:['paradiddle','drag','flam','double'],popHipHop:['paradiddle','double','drag','flam'],reggaeSka:['drag','paradiddle','flam','single']
   };
   return choose(pools[personality]||pools.rockHardRock,phraseIndex+seed);
  };
  const addRudiment=(bar:number,kind:string,variation:number)=>{
   const rollPitch=personality==='funkSoul'||personality==='popHipHop'?GM.snare:GM.snare;
   const tomPitch=personality==='punkDrive'?GM.lowTom:personality==='bluesRock'?GM.midTom:GM.hiTom;
   const baseVelocity=clamp(54+power*42+arcProgressForBar(bar,length)*15,35,118);
   const accent=(i:number)=>i%4===0?13:i%2===0?3:-9;
   if(kind==='single'||kind==='double'){
    const count=skill<.4?8:16;
    for(let i=0;i<count;i++){
     const step=i*(count===8?2:1);
     const pitch=(i%4===3||i%4===2)?tomPitch:rollPitch;
     const velocity=baseVelocity+accent(i)+(kind==='double'&&i%2===1?-8:0);
     const time=bar*4+step*.25+(kind==='double'&&i%2===1?.125:0);
     if(time<(bar+1)*4)out.push({pitch,time,duration:.075,velocity:clamp(Math.round(velocity),1,127)});
    }
   }else if(kind==='paradiddle'){
    const voices=[GM.snare,tomPitch,GM.snare,GM.snare,GM.snare,tomPitch,GM.snare,GM.snare];
    const steps=skill<.4?[0,4,8,12]:[0,2,4,6,8,10,12,14];
    for(let i=0;i<steps.length;i++)out.push({pitch:voices[(i+variation)%voices.length],time:bar*4+steps[i]*.25,duration:.09,velocity:clamp(Math.round(baseVelocity+accent(i)),1,127)});
   }else if(kind==='flam'){
    for(let i=0;i<(skill<.4?2:4);i++){
     const step=(skill<.4?[0,8]:[0,4,8,12])[i],pitch=i%2===0?GM.snare:tomPitch,time=bar*4+step*.25;
     if(time>.04)out.push({pitch,time:time-.055,duration:.045,velocity:clamp(Math.round(baseVelocity-24),1,127)});
     out.push({pitch,time,duration:.10,velocity:clamp(Math.round(baseVelocity+15+(i===3?8:0)),1,127)});
    }
   }else if(kind==='drag'){
    for(let i=0;i<(skill<.4?2:4);i++){
     const step=(skill<.4?[2,10]:[2,6,10,14])[i],pitch=i%2===0?GM.snare:tomPitch,time=bar*4+step*.25;
     out.push({pitch,time:time-.125,duration:.04,velocity:clamp(Math.round(baseVelocity-25),1,127)});
     out.push({pitch,time:time-.0625,duration:.04,velocity:clamp(Math.round(baseVelocity-18),1,127)});
     out.push({pitch,time,duration:.09,velocity:clamp(Math.round(baseVelocity+12),1,127)});
    }
   }else if(kind==='shuffle'){
    for(let i=0;i<(skill<.4?2:4);i++){
     const beat=skill<.4?i*2:i,first=bar*4+beat,third=first+2/3;
     out.push({pitch:GM.snare,time:first,duration:.08,velocity:clamp(Math.round(baseVelocity+7),1,127)});
     out.push({pitch:tomPitch,time:third,duration:.08,velocity:clamp(Math.round(baseVelocity-9),1,127)});
    }
   }
  };
  const arcProgressForBar=(bar:number,total:number)=>total<=1?1:dramaturgyCurve(bar/(total-1));
  // Place one technical phrase per four-bar block. Keep the opening relatively
  // spacious; later blocks become more demanding as the solo approaches its peak.
  for(let block=0;block<Math.ceil(length/4);block++){
   const start=block*4,available=Math.min(4,length-start);if(available<2)continue;
   const phraseBar=start+Math.min(available-1,block===0?2:1+(seed%2));
   const kind=rudimentFor(block);
   if(skill<.28&&kind==='single')continue;
   addRudiment(phraseBar,kind,block);
  }
  // Reprise the opening two-bar idea later with a displaced accent and altered
  // orchestration: recognizable, but never a literal copy of the opening.
  if(length>=8){
   const opening=out.filter(n=>n.time<4&&[GM.kick,GM.snare,GM.midTom,GM.lowTom].includes(n.pitch)).slice(0,10);
   const repriseBar=Math.min(length-2,Math.max(4,Math.floor(length/2)));
   for(let i=0;i<opening.length;i++){
    const n=opening[i],step=Math.round((n.time/.25)),shift=(i%2===0?1:-1),targetStep=clamp(step+shift,0,15);
    const pitch=n.pitch===GM.kick?GM.kick:n.pitch===GM.snare?(i%3===0?GM.midTom:GM.snare):n.pitch===GM.midTom?GM.lowTom:GM.midTom;
    const time=repriseBar*4+targetStep*.25;
    if(!out.some(x=>x.pitch===pitch&&Math.abs(x.time-time)<.001))out.push({pitch,time,duration:.09,velocity:clamp(Math.round(n.velocity*(.78+skill*.12)),24,112)});
   }
  }
 }
 // Interaction layer: two-bar call/response. The first bar states a compact motif;
 // the next bar answers on a different voice with a small rhythmic displacement.
 // Every four bars, a shortened echo recalls the opening idea with altered voicing.
 if(soloType==='fullSolo'&&length>=4){
  const source=out.slice();
  const responsePitch=(pitch:number,bar:number)=>{
   if(pitch===GM.kick)return bar%4===3?GM.lowTom:GM.midTom;
   if(pitch===GM.snare)return bar%4===3?GM.lowTom:GM.midTom;
   if(pitch===GM.midTom)return GM.snare;
   if(pitch===GM.lowTom)return GM.midTom;
   return null;
  };
  for(let bar=1;bar<length;bar+=2){
   const callBar=bar-1;
   const calls=source.filter(n=>Math.floor(n.time/4)===callBar&&(n.pitch===GM.kick||n.pitch===GM.snare||n.pitch===GM.midTom||n.pitch===GM.lowTom));
   for(const n of calls){
    const pitch=responsePitch(n.pitch,bar);if(pitch===null)continue;
    const step=((n.time-callBar*4)/.25);
    const shifted=bar*4+Math.min(15,Math.max(0,step+(step>=8?1:-1)))*.25;
    if(!out.some(x=>x.pitch===pitch&&Math.abs(x.time-shifted)<.001))
     out.push({pitch,time:shifted,duration:.09,velocity:clamp(Math.round(n.velocity*(.62+skill*.12)),24,105)});
   }
  }
  // Recall the first two-bar motif in bar five, but thin it and move selected notes to toms.
  if(length>=8){
   const opening=source.filter(n=>n.time<4&&(n.pitch===GM.kick||n.pitch===GM.snare));
   for(const n of opening){
    const pitch=n.pitch===GM.kick?GM.kick:GM.midTom;
    const step=Math.round((n.time/.25));
    const shifted=16+Math.min(15,step+(step%4===0?1:0))*.25;
    if(!out.some(x=>x.pitch===pitch&&Math.abs(x.time-shifted)<.001))
     out.push({pitch,time:shifted,duration:.1,velocity:clamp(Math.round(n.velocity*.78),28,112)});
   }
  }
 }
 // Full Solo has no final-bar break, fill or isolated cadence hit; the groove carries on.
 if(soloType==='soloOutro'){
  const last=length-1;for(let i=out.length-1;i>=0;i--)if(out[i].time>=last*4)out.splice(i,1);
  add(last,[0],GM.kick,127,4);add(last,[0],GM.crash,127,4);
 }else if(soloType==='drumBreak'&&length>1){
  const last=length-1;add(last,[12,14,15],GM.snare,clamp(82+power*32,1,120));
 }
 // Song integration: shape the opening pickup from the preceding section and
 // tailor the final hand-off to the next section. The clip remains standalone.
 const sectionKey=(value:string)=>String(value||'').toLowerCase().replace(/[^a-z]/g,'');
 const previous=sectionKey(previousSection),next=sectionKey(nextSection);
 if(soloType==='fullSolo'||soloType==='drumBreak'){
  // A short, genre-aware pickup gives the solo a sense of arriving from the song groove.
  if(length>=2){
   const entryBar=0;
   if(previous.includes('chorus')){
    add(entryBar,[0],GM.crash,clamp(78+power*24,1,112));
    add(entryBar,[14,15],GM.snare,clamp(72+power*20,1,108));
   }else if(previous.includes('bridge')){
    add(entryBar,[12,15],GM.lowTom,clamp(66+power*22,1,104));
   }else if(previous.includes('intro')){
    add(entryBar,[0,8],GM.kick,clamp(68+power*20,1,104));
   }else{
    add(entryBar,[14,15],GM.snare,clamp(62+power*18,1,98));
   }
  }
  const last=length-1;
  // Remove generic full-solo cadence hits before composing a destination-aware hand-off.
  if(soloType==='fullSolo'){
   for(let i=out.length-1;i>=0;i--)if(out[i].time>=last*4+3.7&&out[i].pitch===GM.crash)out.splice(i,1);
   if(next.includes('chorus')){
    add(last,[12,14,15],GM.snare,clamp(94+power*30,1,124));
    add(last,[15],GM.kick,clamp(100+power*25,1,127),.22);
   }else if(next.includes('bridge')){
    add(last,[12,14],GM.lowTom,clamp(82+power*24,1,116));
    add(last,[15],GM.snare,clamp(88+power*22,1,118),.22);
   }else if(next.includes('verse')){
    add(last,[12,14],GM.snare,clamp(76+power*18,1,108));
    
   }else if(next.includes('outro')){
    add(last,[12,14,15],GM.lowTom,clamp(86+power*24,1,118));
    
   }else{
    add(last,[15],GM.snare,clamp(104+power*23,1,127),.22);
    
   }
  }
 }
 if(soloType==='fullSolo')continueFullSoloThroughLastBar();
 removeFinalCrash();
 return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
}
