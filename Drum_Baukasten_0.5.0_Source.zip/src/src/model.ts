export type Genre = "classicRock" | "bluesRock" | "alternativeRock" | "punk" | "reggae" | "ska" | "funk" | "hipHop";
export type SectionType = "Intro" | "Verse" | "Chorus" | "Bridge" | "Outro";
export interface Section { id: string; type: SectionType; name: string; bars: number; intensity: number; variant: number; }
export interface Note { pitch: number; time: number; duration: number; velocity: number; }
export interface Pattern { kick: number[]; snare: number[]; rim: number[]; hat: number[]; openHat: number[]; crash: number[]; ride: number[]; hiTom: number[]; midTom: number[]; lowTom: number[]; }
export const GENRES: {key: Genre; label: string}[] = [
 {key:"classicRock",label:"Classic Rock"},{key:"bluesRock",label:"Blues Rock"},{key:"alternativeRock",label:"Alternative Rock"},{key:"punk",label:"Punk"},{key:"reggae",label:"Reggae"},{key:"ska",label:"Ska"},{key:"funk",label:"Funk"},{key:"hipHop",label:"Hip-Hop"}
];
export const DEFAULT_SECTIONS: Section[] = [
 {id:"intro",type:"Intro",name:"Intro",bars:4,intensity:42,variant:0},
 {id:"verse1",type:"Verse",name:"Verse 1",bars:12,intensity:55,variant:1},
 {id:"chorus1",type:"Chorus",name:"Chorus 1",bars:8,intensity:82,variant:2},
 {id:"verse2",type:"Verse",name:"Verse 2",bars:12,intensity:60,variant:3},
 {id:"chorus2",type:"Chorus",name:"Chorus 2",bars:8,intensity:88,variant:4},
 {id:"bridge",type:"Bridge",name:"Bridge",bars:8,intensity:48,variant:5},
 {id:"chorus3",type:"Chorus",name:"Final Chorus",bars:8,intensity:94,variant:6},
 {id:"outro",type:"Outro",name:"One-Bar Outro",bars:1,intensity:100,variant:7}
];
const eighth = [0,2,4,6,8,10,12,14];
const sixteenth = Array.from({length:16},(_,i)=>i);
const P = (kick:number[],snare:number[],hat:number[],extra:Partial<Pattern>={}):Pattern=>({kick,snare,rim:[],hat,openHat:[],crash:[],ride:[],hiTom:[],midTom:[],lowTom:[],...extra});
export const PATTERNS: Record<Genre, Pattern[]> = {
 classicRock:[P([0,8],[4,12],eighth,{crash:[0],openHat:[14]}),P([0,4,8,12],[4,12],eighth,{crash:[0,8],openHat:[6,14]}),P([0,6,8,14],[4,12],eighth,{crash:[0],midTom:[15]})],
 bluesRock:[P([0,8],[4,12],eighth,{ride:eighth,rim:[3,7,11,15]}),P([0,6,8,14],[4,12],eighth,{ride:eighth,openHat:[6,14]}),P([0,8,10],[4,12],eighth,{ride:eighth,midTom:[14]})],
 alternativeRock:[P([0,8],[4,12],eighth),P([0,6,8,14],[4,11,12],eighth,{openHat:[6],rim:[7,15]}),P([0,4,8,12],[4,12],[0,4,8,12],{openHat:[2,10],crash:[0,8],midTom:[15]})],
 punk:[P(eighth,[4,12],eighth,{crash:[0],openHat:[2,6,10,14]}),P([0,4,8,12],[4,12],eighth,{crash:[0,8],openHat:[6,14]}),P([0,2,4,6,8,10,12,14],[4,12],eighth,{crash:[0],rim:[7,15]})],
 reggae:[P([8],[],eighth,{rim:[8]}),P([0,8],[],eighth,{rim:[8],openHat:[6,14]}),P([8,14],[4,12],eighth,{rim:[8],openHat:[14]})],
 ska:[P([0,8],[4,12],[2,6,10,14],{openHat:[2,6,10,14]}),P([0,4,8,12],[4,12],eighth,{openHat:[2,6,10,14],crash:[0]}),P([0,8,10],[4,12],eighth,{openHat:[2,6,10,14],rim:[7,15]})],
 funk:[P([0,7,10],[4,12],sixteenth,{rim:[3,7,11,15],openHat:[14]}),P([0,3,8,10,14],[4,12],sixteenth,{rim:[2,6,11,15],openHat:[6,14]}),P([0,6,8,11],[4,12],eighth,{rim:[3,7,11,15],openHat:[2,10,14]})],
 hipHop:[P([0,7,10],[4,12],eighth,{rim:[3,11,15]}),P([0,6,10,14],[4,12],eighth,{rim:[3,7,11,15],openHat:[14]}),P([0,8,11],[4,12],[0,2,4,6,8,10,12,14],{rim:[7,15],openHat:[6,14]})]
};
const GM = {kick:36,snare:38,rim:37,hat:42,openHat:46,crash:49,ride:51,hiTom:50,midTom:47,lowTom:43};
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
function stablePick<T>(items:T[], index:number):T { return items[((index%items.length)+items.length)%items.length]; }
function addLane(out:Note[], steps:number[], pitch:number, bar:number, velocity:number, offset=0) {
 for (const s of steps) out.push({pitch,time:bar*4+s/4+offset,duration:0.12,velocity:clamp(velocity,1,127)});
}
type FillLength = "quarter" | "half" | "full";
function fillFor(genre:Genre, bar:number, intensity:number, variant:number, out:Note[], length:FillLength) {
 const beats = length === "full" ? 4 : length === "half" ? 2 : 1;
 const startBeat = 4 - beats;
 const start = bar*4 + startBeat;
 const vel=clamp(72+intensity*.42,1,127);
 const local=(steps:number[],pitch:number,v=vel,spacing=0.25)=>{
   for(const step of steps) out.push({pitch,time:start+step*spacing,duration:0.10,velocity:clamp(v,1,127)});
 };
 const technique=(Math.abs(variant*7+bar*3+Math.floor(intensity/10))%4);
 // Every fill family uses a distinct rhythmic grammar. The selector is deterministic
 // for reproducible MIDI, but changes with phrase/bar/section variation.
 if(genre==="punk") {
   const dense = variant%3!==0 || intensity>=65;
   if(technique===0) { // fast tom run
     const pitches=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom,GM.hiTom,GM.lowTom,GM.snare,GM.crash];
     const count=beats*4;
     for(let i=0;i<count;i++) out.push({pitch:pitches[i%pitches.length],time:start+i*.25,duration:.09,velocity:clamp(vel+(i%4===0?8:0),1,127)});
   } else if(technique===1) { // snare roll crescendo
     const count=beats*8;
     for(let i=0;i<count;i++) out.push({pitch:GM.snare,time:start+i*.125,duration:.07,velocity:clamp(vel-18+i*(34/Math.max(1,count-1)),1,127)});
     local([beats*4-1],GM.crash,vel+9);
   } else if(technique===2) { // linear alternating kick/snare/toms
     const voices=[GM.kick,GM.snare,GM.hiTom,GM.midTom,GM.lowTom,GM.snare,GM.kick,GM.lowTom];
     for(let i=0;i<beats*4;i++) out.push({pitch:voices[(i+variant)%voices.length],time:start+i*.25,duration:.09,velocity:clamp(vel+(i%4===0?7:0),1,127)});
   } else { // triplet burst
     for(let b=0;b<beats;b++) for(let j=0;j<3;j++) out.push({pitch:[GM.snare,GM.hiTom,GM.lowTom][(j+b+variant)%3],time:start+b+j/3,duration:.09,velocity:clamp(vel+(j===0?7:0),1,127)});
     local([beats*4-1],GM.crash,vel+9);
   }
   if(!dense) for(let i=out.length-1;i>=0;i--) if(out[i].time>=start && out[i].time<(bar+1)*4 && out[i].velocity<vel-4) out.splice(i,1);
   return;
 }
 if(genre==="alternativeRock") {
   const mode=technique;
   if(mode===0) { // tom run with changing direction
     const up=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom], down=[GM.lowTom,GM.midTom,GM.hiTom,GM.snare];
     for(let i=0;i<beats*4;i++) out.push({pitch:(variant%2?up:down)[i%4],time:start+i*.25,duration:.10,velocity:clamp(vel+(i%4===0?6:0),1,127)});
     local([beats*4-1],GM.crash,vel+8);
   } else if(mode===1) { // crescendo snare roll, resolves to tom/crash
     const count=beats*8;
     for(let i=0;i<count;i++) out.push({pitch:GM.snare,time:start+i*.125,duration:.07,velocity:clamp(vel-20+i*(38/Math.max(1,count-1)),1,127)});
     local([beats*4-2],GM.lowTom,vel+4); local([beats*4-1],GM.crash,vel+10);
   } else if(mode===2) { // linear alternative-rock phrase
     const voices=[GM.kick,GM.snare,GM.hiTom,GM.midTom,GM.snare,GM.lowTom,GM.kick,GM.midTom];
     for(let i=0;i<beats*4;i++) out.push({pitch:voices[(i+variant)%voices.length],time:start+i*.25,duration:.10,velocity:clamp(vel+(i%4===0?8:0),1,127)});
   } else { // triplet accents
     for(let b=0;b<beats;b++) for(let j=0;j<3;j++) out.push({pitch:[GM.snare,GM.midTom,GM.lowTom][(j+Math.abs(variant))%3],time:start+b+j/3,duration:.10,velocity:clamp(vel+(j===0?8:0),1,127)});
     local([beats*4-1],GM.crash,vel+9);
   }
   return;
 }
 // Other genres rotate through the same techniques, with genre-specific voicing.
 if(genre==="classicRock" || genre==="bluesRock") {
   if(technique===0) {
     const run=[GM.hiTom,GM.midTom,GM.lowTom,GM.midTom];
     for(let i=0;i<beats*4;i++) out.push({pitch:run[(i+variant)%4],time:start+i*.25,duration:.10,velocity:clamp(vel+(i%4===0?6:0),1,127)});
     local([beats*4-1],GM.crash,vel+8);
   } else if(technique===1) {
     const count=beats*8; for(let i=0;i<count;i++) out.push({pitch:GM.snare,time:start+i*.125,duration:.07,velocity:clamp(vel-16+i*(32/Math.max(1,count-1)),1,127)});
     local([beats*4-1],GM.crash,vel+8);
   } else if(technique===2) {
     const voices=[GM.kick,GM.snare,GM.hiTom,GM.midTom,GM.lowTom,GM.snare];
     for(let i=0;i<beats*4;i++) out.push({pitch:voices[(i+variant)%voices.length],time:start+i*.25,duration:.10,velocity:clamp(vel+(i%4===0?6:0),1,127)});
   } else {
     for(let b=0;b<beats;b++) for(let j=0;j<3;j++) out.push({pitch:[GM.snare,GM.midTom,GM.lowTom][(j+variant)%3],time:start+b+j/3,duration:.10,velocity:clamp(vel+(j===0?6:0),1,127)});
     local([beats*4-1],GM.crash,vel+8);
   }
 } else if(genre==="funk") {
   const voices=[GM.kick,GM.snare,GM.hiTom,GM.rim,GM.midTom,GM.snare,GM.lowTom,GM.kick];
   for(let i=0;i<beats*4;i++) out.push({pitch:voices[(i+variant)%voices.length],time:start+i*.25,duration:.09,velocity:clamp(vel+(i%4===0?7:-14),1,127)});
 } else if(genre==="reggae" || genre==="ska") {
   for(let b=0;b<beats;b++) for(let j=0;j<3;j++) out.push({pitch:[GM.rim,GM.snare,GM.midTom][(j+variant)%3],time:start+b+j/3,duration:.10,velocity:clamp(vel+(j===0?4:-8),1,127)});
 } else {
   if(technique===0) { const run=[GM.hiTom,GM.midTom,GM.lowTom]; for(let i=0;i<beats*4;i++) out.push({pitch:run[i%3],time:start+i*.25,duration:.1,velocity:vel}); }
   else { const count=beats*8; for(let i=0;i<count;i++) out.push({pitch:GM.snare,time:start+i*.125,duration:.07,velocity:clamp(vel-16+i*(30/Math.max(1,count-1)),1,127)}); }
 }
}
export function generateSectionNotes(genre:Genre, section:Section, seed=17):Note[] {
 const out:Note[]=[]; const patterns=PATTERNS[genre];
 for(let bar=0;bar<section.bars;bar++){
   const absoluteVariant=section.variant+Math.floor(bar/2)+seed;
   const basePattern=stablePick(patterns,absoluteVariant);
   let p=basePattern;
   if(genre==="alternativeRock") {
     const v=section.variant+Math.floor(bar/2)+seed;
     if(section.type==="Verse") {
       // Verse: tighter, more spacious pulse, restrained cymbals and syncopated kick.
       const verseGrooves=[
         P([0,8],[4,12],eighth,{rim:[7,15]}),
         P([0,6,8],[4,12],eighth,{openHat:[14]}),
         P([0,8,14],[4,12],[0,4,8,12],{rim:[7,15]})
       ];
       p=stablePick(verseGrooves,v);
     } else if(section.type==="Chorus") {
       // Chorus: wider, more driving pulse with stronger backbeat and cymbal lift.
       const chorusGrooves=[
         P([0,4,8,12],[4,12],eighth,{crash:[0,8],openHat:[6,14]}),
         P([0,6,8,14],[4,12],eighth,{crash:[0],openHat:[2,6,10,14]}),
         P([0,4,8,10,12],[4,12],[0,2,4,6,8,10,12,14],{crash:[0,8],openHat:[6,14]})
       ];
       p=stablePick(chorusGrooves,v+1);
     } else if(section.type==="Bridge") {
       p=P([0,8],[4,12],[0,4,8,12],{rim:[3,11]});
     }
   }
   const intensity=section.intensity;
   const baseVel=clamp(48+intensity*.55,1,127);
   const kickVel=clamp(baseVel+12,1,127), snareVel=clamp(baseVel+8,1,127), hatVel=clamp(baseVel-14,1,127);
   if(!(section.type==="Intro" && bar===0 && intensity<50)) addLane(out,p.kick,GM.kick,bar,kickVel);
   addLane(out,p.snare,GM.snare,bar,snareVel);
   addLane(out,p.rim,GM.rim,bar,Math.max(22,hatVel-8));
   addLane(out,p.hat,GM.hat,bar,hatVel);
   addLane(out,p.openHat,GM.openHat,bar,Math.min(127,hatVel+8));
   addLane(out,p.ride,GM.ride,bar,hatVel+4);
   addLane(out,p.crash,GM.crash,bar,Math.min(127,baseVel+28));
   addLane(out,p.hiTom,GM.hiTom,bar,baseVel+2); addLane(out,p.midTom,GM.midTom,bar,baseVel+2); addLane(out,p.lowTom,GM.lowTom,bar,baseVel+2);
   if(section.type==="Chorus" && bar===0) addLane(out,[0],GM.crash,bar,Math.min(127,baseVel+30));
   if(section.type==="Bridge" && bar%2===0 && genre!=="reggae") addLane(out,[0],GM.crash,bar,baseVel+12);
   const isSectionEnd=bar===section.bars-1;
   // Phrase-based schedule: no recurring every-N-bars fills. A 16-bar section
   // gets a full-bar fill at bar 8 and bar 16; shorter sections scale the midpoint.
   const phraseFills = new Map<number,FillLength>();
   if(section.bars>=16){phraseFills.set(3,section.variant%2===0?"quarter":"half");phraseFills.set(7,"full");phraseFills.set(11,section.variant%2===0?"half":"quarter");}
   else if(section.bars>=12){phraseFills.set(3,"quarter");phraseFills.set(7,"half");}
   else if(section.bars>=8){phraseFills.set(Math.floor(section.bars/2)-1,"half");}
   else if(section.bars>=4){phraseFills.set(Math.floor(section.bars/2)-1,"quarter");}
   const scheduledFill=phraseFills.get(bar);
   if(isSectionEnd || scheduledFill) {
     const fillLength:FillLength = isSectionEnd ? "full" : scheduledFill!;
     if(!(genre==="reggae" && isSectionEnd)) {
       const beats = fillLength==="full" ? 4 : fillLength==="half" ? 2 : 1;
       const from = bar*4 + (4-beats);
       for(let i=out.length-1;i>=0;i--) if(out[i].time>=from && out[i].time<(bar+1)*4) out.splice(i,1);
       fillFor(genre,bar,intensity,absoluteVariant,out,fillLength);
     }
   }
 }
 return out.sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
}
export function buildArrangement(genre:Genre, sections:Section[], seed=17) {
 let cursor=0;
 const built=sections.map((section)=>{
   const safeSection={...section,bars:Math.max(1,Math.min(16,Math.round(Number(section.bars)||1)))};
   const notes=generateSectionNotes(genre,safeSection,seed+cursor);
   const result={...safeSection,startBar:cursor,notes}; cursor+=safeSection.bars; return result;
 });
 const allNotes=built.flatMap(s=>s.notes.map(n=>({...n,time:n.time+s.startBar*4}))).sort((a,b)=>a.time-b.time||a.pitch-b.pitch);
 return {genre,totalBars:cursor,sections:built,notes:allNotes};
}
