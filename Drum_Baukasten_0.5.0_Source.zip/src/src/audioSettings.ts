import fs from 'node:fs';
import path from 'node:path';

export const DEFAULT_PREVIEW_VOLUME = 70;
const SETTINGS_FILE = 'audio-settings.json';

export interface DrumBaukastenSettings { previewVolume: number; uiState?: Record<string, unknown>; }

export function readSettings(storageDirectory?: string): DrumBaukastenSettings {
  if (!storageDirectory) return { previewVolume: DEFAULT_PREVIEW_VOLUME };
  try {
    const file = path.join(storageDirectory, SETTINGS_FILE);
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    const value = Number(data?.previewVolume);
    return { previewVolume: Number.isFinite(value) && value >= 0 && value <= 100 ? Math.round(value) : DEFAULT_PREVIEW_VOLUME, uiState: data?.uiState && typeof data.uiState === 'object' && !Array.isArray(data.uiState) ? data.uiState : undefined };
  } catch { return { previewVolume: DEFAULT_PREVIEW_VOLUME }; }
}

export function readPreviewVolume(storageDirectory?: string): number { return readSettings(storageDirectory).previewVolume; }

export function writeSettings(storageDirectory: string | undefined, volume: number, uiState?: Record<string, unknown>): number {
  if (!storageDirectory) throw new Error('Ableton did not provide a persistent extension storage directory.');
  const value = Number(volume);
  if (!Number.isFinite(value) || value < 0 || value > 100) {
    throw new Error('Preview volume must be a number between 0 and 100.');
  }
  fs.mkdirSync(storageDirectory, { recursive: true });
  const file = path.join(storageDirectory, SETTINGS_FILE);
  const temporaryFile = `${file}.tmp-${process.pid}`;
  const existing = readSettings(storageDirectory);
  fs.writeFileSync(temporaryFile, JSON.stringify({ previewVolume: Math.round(value), uiState: uiState && typeof uiState === 'object' ? uiState : existing.uiState }, null, 2), 'utf8');
  fs.renameSync(temporaryFile, file);
  return Math.round(value);
}

export function writePreviewVolume(storageDirectory: string | undefined, volume: number): number { return writeSettings(storageDirectory, volume); }
