/** Drum Construction Kit. Independent third-party extension for Ableton Live. */
import { initialize, ClipSlot, MidiTrack, type ActivationContext, type Handle } from "@ableton-extensions/sdk";
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { buildUiHtml, type TrackInfo } from "./ui";
import { readSettings, writeSettings } from "./audioSettings";
import { generateSoloNotes } from "./soloEngine";

interface ArrangementMessage {
  type: "createArrangement";
  genre: string;
  bpm: number;
  sections: { name: string; genre?: string; drummerStyle?: string; bars: number; notes: { pitch:number; time:number; duration:number; velocity:number }[] }[];
  sectionTrack: number;
  sectionStartSlot: number;
}
function dialogHtml(title:string,message:string):string {
 return `<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;background:#101216;color:#f5f7fa;font:13px -apple-system,Arial;display:flex;flex-direction:column;justify-content:center;align-items:center;height:100vh;text-align:center;padding:0 24px;box-sizing:border-box}h2{font-size:16px;margin:0 0 10px}p{color:#d3d9e3;line-height:1.5}button{background:#d94f16;color:white;border:0;border-radius:6px;padding:9px 22px;cursor:pointer}</style></head><body><h2>${title}</h2><p>${message}</p><button id="ok">OK</button><script>document.getElementById('ok').onclick=()=>{const m={method:'close_and_send',params:['{}']};if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.live)window.webkit.messageHandlers.live.postMessage(m);else if(window.chrome&&window.chrome.webview)window.chrome.webview.postMessage(m);};</script></body></html>`;
}
async function showMessage(context:ReturnType<typeof initialize>,title:string,message:string){try{await context.ui.showModalDialog(`data:text/html,${encodeURIComponent(dialogHtml(title,message))}`,420,240);}catch{}}
export function activate(activation:ActivationContext){
 const context=initialize(activation,"1.0.0");
 context.commands.registerCommand("drumBaukasten.open",(arg:unknown)=>(async(handle:Handle)=>{
   let fallback:ClipSlot<"1.0.0">|null=null;
   try{fallback=context.getObjectFromHandle(handle,ClipSlot);}catch{}
   const allTracks=context.application.song.tracks;
   let defaultTarget:{trackIndex?:number;slotIndex?:number}={};
   if(fallback){for(let ti=0;ti<allTracks.length;ti++){const si=allTracks[ti].clipSlots.findIndex(s=>s===fallback);if(si>=0){defaultTarget={trackIndex:ti,slotIndex:si};break;}}}
   const tracks:TrackInfo[]=allTracks.map((track,index)=>({track,index})).filter(x=>x.track instanceof MidiTrack).map(({track,index})=>({index,name:track.name||`MIDI ${index+1}`,slots:track.clipSlots.map((slot,index)=>({index,occupied:!!slot.clip}))}));
   const storageDirectory=context.environment.storageDirectory;
   const savedSettings=readSettings(storageDirectory);
   const html=buildUiHtml(tracks,savedSettings,defaultTarget);
   // Store settings natively in Ableton's persistent per-extension directory.
   // The dialog returns the complete current UI state on Cancel and both Create actions.
   // Native storage survives extension windows and Live sessions.
   let dialogUrl=`data:text/html,${encodeURIComponent(html)}`;
   if(storageDirectory){
     try{
       fs.mkdirSync(storageDirectory,{recursive:true});
       const uiPath=path.join(storageDirectory,"drum-construction-kit-ui.html");
       fs.writeFileSync(uiPath,html,"utf8");
       dialogUrl=pathToFileURL(uiPath).href;
     }catch{/* The UI can still run; settings are persisted after dialog return. */}
   }
   let result:string;
   try{result=await context.ui.showModalDialog(dialogUrl,1120,820);}catch{return;}
   let msg:any;try{msg=JSON.parse(result);}catch{return;}
   let settingsSaveError:string|undefined;
   try{writeSettings(storageDirectory,msg.previewVolume,msg.uiState);}catch(err){settingsSaveError=err instanceof Error?err.message:String(err);}
   if(msg.type==="createSolo"){
     if(settingsSaveError)await showMessage(context,"Preview Setting Not Saved",settingsSaveError);
     const soloTracks=context.application.song.tracks;
     const targetTrack=soloTracks[Number(msg.sectionTrack)];
     if(!(targetTrack instanceof MidiTrack)){await showMessage(context,"MIDI track required","Please select a valid MIDI track for the drum solo.");return;}
     const targetSlot=targetTrack.clipSlots[Number(msg.sectionStartSlot)];
     if(!targetSlot||targetSlot.clip){await showMessage(context,"Clip slot unavailable","Choose one free clip slot. No existing clip was changed.");return;}
     const allowedGenres=["classicRock","bluesRock","alternativeRock","punk","reggae","ska","funk","hipHop"];
     const soloGenre=allowedGenres.includes(msg.genre)?msg.genre:"classicRock";
     const soloBars=Math.max(1,Math.min(32,Math.round(Number(msg.bars)||8)));
     const soloBpm=Math.max(40,Math.min(240,Number(msg.bpm)||120));
     const soloNotes=generateSoloNotes(soloGenre,soloBars,String(msg.soloType||"fullSolo"),Number.isFinite(Number(msg.intensity))?Number(msg.intensity):75,Number.isFinite(Number(msg.complexity))?Number(msg.complexity):65,Math.floor(Date.now()/1000)%997,String(msg.drummerStyle||"powerSwing"),String(msg.previousSection||"verse"),String(msg.nextSection||"chorus"));
     const genreLabels:Record<string,string>={classicRock:"Classic Rock",bluesRock:"Blues Rock",alternativeRock:"Alternative Rock",punk:"Punk",reggae:"Reggae",ska:"Ska",funk:"Funk",hipHop:"Hip-Hop"};
     try{await context.withinTransaction(()=>{context.application.song.tempo=soloBpm;return targetSlot.createMidiClip(soloBars*4).then(clip=>{const typeLabels:Record<string,string>={fullSolo:"Full Solo",drumBreak:"Drum Break",tradingFours:"Trading Fours",soloOutro:"Solo Outro"};clip.name=`Drum Solo · ${genreLabels[soloGenre]} · ${typeLabels[String(msg.soloType)]||"Full Solo"} · ${soloBars} Bars`;clip.notes=soloNotes.map(n=>({pitch:n.pitch,startTime:n.time,duration:Math.max(.01,Math.min(n.duration,soloBars*4-n.time)),velocity:n.velocity}));});});}catch(err){await showMessage(context,"Drum Solo Creation Failed","Live could not create the solo clip. Check the selected MIDI track and clip slot, then try again.");}
     return;
   }
   if(msg.type!=="createArrangement"){
     if(settingsSaveError)await showMessage(context,"Preview Setting Not Saved",settingsSaveError);
     return; // Cancel closes without touching the Live set.
   }
   const songTracks=context.application.song.tracks;
   const sectionTrack=songTracks[msg.sectionTrack];
   if(!(sectionTrack instanceof MidiTrack)){await showMessage(context,"MIDI track required","Please select a valid MIDI track for the section clips.");return;}
   if(!Array.isArray(msg.sections)||!msg.sections.length){await showMessage(context,"No arrangement","No valid section data was received.");return;}
   const sectionSlots=msg.sections.map((_,i)=>sectionTrack.clipSlots[msg.sectionStartSlot+i]);
   if(sectionSlots.some(s=>!s)){await showMessage(context,"Not Enough Arrangement Space","There are not enough consecutive empty clip slots on the selected MIDI track for all song sections. Please free up enough slots or choose another track or start slot, then try again.");return;}
   if(sectionSlots.some(s=>!!s.clip)){await showMessage(context,"Not Enough Arrangement Space","One or more required clip slots on the selected MIDI track are already occupied. Nothing was created. Please choose a free range of consecutive slots and try again.");return;}
   try{
     await context.withinTransaction(()=>{
       context.application.song.tempo=Math.max(40,Math.min(240,Number(msg.bpm)||120));
       let chain:Promise<unknown>=Promise.resolve();
       msg.sections.forEach((section,i)=>{chain=chain.then(()=>sectionSlots[i].createMidiClip(Math.max(1,Math.min(16,Math.round(Number(section.bars)||1)))*4).then(clip=>{const profileNames:Record<string,string>={powerSwing:'Power & Swing',rollingToms:'Fast Rolling Toms',jazzShuffle:'Jazz Shuffle',texasShuffle:'Texas Shuffle',heavyBackbeat:'Heavy Backbeat',dynamicToms:'Dynamic Toms',straightEighths:'Straight Eighths',precisionFills:'Fast Precision Fills',oneDrop:'One Drop',tightReggae:'Tight Reggae',offbeatSka:'Offbeat Ska',twoToneSka:'Two-Tone Ska',ghostNoteFunk:'Ghost-Note Funk',linearFunk:'Linear Funk',deepPocket:'Deep Pocket',brokenBeats:'Broken Beats'};const clipGenre=section.genre||msg.genre;const drummer=profileNames[section.drummerStyle||'']||section.drummerStyle||'Default';const clipBars=Math.max(1,Math.min(16,Math.round(Number(section.bars)||1)));clip.name=section.name.includes(" Bars")?`${section.name} · ${clipGenre} · ${drummer}`:`${section.name} · ${clipBars} Bars · ${clipGenre} · ${drummer}`;clip.notes=section.notes.filter(n=>Number.isFinite(n.time)&&n.time>=0&&n.time<clipBars*4-.01).map(n=>({pitch:n.pitch,startTime:n.time,duration:Math.max(.01,Math.min(Number(n.duration)||.12,clipBars*4-.01-n.time)),velocity:Math.max(1,Math.min(127,Math.round(Number(n.velocity)||1)))}));}));});
       return chain;
     });
     // Successful creation closes silently; no redundant export confirmation window.
     if(settingsSaveError)await showMessage(context,"Preview Setting Not Saved",settingsSaveError);
   }catch(err){await showMessage(context,"MIDI Clip Creation Failed","Live could not create the complete arrangement. Please check the selected MIDI track and available clip slots before trying again. If any clips were created, inspect the track before repeating the operation.");}
 })(arg as Handle));
 context.ui.registerContextMenuAction("ClipSlot","Drum Construction Kit…","drumBaukasten.open");
}
