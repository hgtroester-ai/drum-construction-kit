# Changelog

## 0.5.0 — Hip-Hop Drum Solo
- Added a dedicated Hip-Hop Complete Solo engine with boom-bap backbeat, syncopated kick vocabulary, relaxed closed-hat pulse and low-velocity ghost snares.
- Added sparse rim/tom phrase punctuation instead of continuous rock-style tom runs.
- Preserved full final-bar continuity with no forced crash; Drum Break, Trading Fours and Solo Outro retain their separate behaviors.
- Updated Hip-Hop solo personality label and added regression tests.


## 0.4.7 — Solo Continuity & Type Separation
- Complete Solo now plays continuously through the final bar in all eight genres; no last-bar break, fill or isolated cadence hit.
- Drum Break now uses a dedicated compact, syncopated break engine.
- Trading Fours remains a clear four-bar solo / four-bar reduced-timekeeping exchange.
- Updated Solo Type descriptions and regression coverage.
# Drum Construction Kit – Changelog

## 0.4.6 – Solo Type Logic
- Complete Solo ends with a genre-appropriate snare/tom resolution; no automatic final crash.
- Solo Outro now uses genre-aware lead phrasing and reserves the final bar for the sustained kick + crash downbeat.
- Drum Break remains a compact break with a clear return-ready ending.
- Trading Fours retains alternating four-bar solo and timekeeping phrases across all eight genres.
- Regression coverage expanded across 32 genre/Solo-Type combinations.


## 0.4.2 – Blues Rock Shuffle Motif Solo
- Added a dedicated Blues Rock full-solo composer with a swung ride ostinato and recurring kick/snare motif.
- Added call-and-response tom phrases, restrained ghost notes, shuffle turnarounds and a decisive final cadence.
- Supports the existing 16- and 32-bar solo lengths; the same motif develops across longer forms.
- Classic Rock 0.4.1 behavior, other genre engines, audio assets and song-section integration remain unchanged.


## 0.4.1 – Classic Rock Motif-Based Hybrid Solo
- Reworked the Classic Rock full solo into a 16-bar motif-led composition: statement, transformed reprise, development, controlled climax and a decisive shared final downbeat.
- Added restrained seed variation and complexity-sensitive phrase density while keeping the kick/snare identity recognizable.
- Added phrase-based tom responses and short rudimental bursts instead of unrelated continuous fills.
- Preserved the other genre engines and existing song-section / solo-outro behavior.


## 0.4.0 – Classic Rock Solo Drum
- Added a composed Classic Rock eight-bar solo arc: crash-led opening, hand-foot triplets, syncopated tom phrases, sixteenth-note runs, flam-like accents, and a kick/crash finale on beat one.
- Longer Classic Rock full solos develop through repeated eight-bar arcs with changed orchestration and accents.
- Seed variation changes phrase details while preserving the overall musical structure.
- Other genres and non-full-solo types retain the 0.3.18 solo engine behavior.


## 0.3.18 – Solo Intelligence
- Added a genre-aware rudiment layer for Full Solo: single-stroke and double-stroke rolls, paradiddle phrasing, flams, drags and shuffle triplet figures.
- Added short technical phrases at phrase-aware positions; note density and velocity follow complexity, intensity and the solo's dramaturgical arc.
- Added a transformed reprise of the opening motif later in longer solos, preserving recognition while changing accents and orchestration.
- Preserved existing solo types, GUI controls, genre personalities, song hand-off behavior and the exact Solo Outro ending.

- 16-bar sections now use four planned fill points across all genres: bar 4 (quarter- or half-bar), bar 8 (full bar), bar 12 (the complementary quarter- or half-bar), and bar 16 (full bar).
- The two shorter fills alternate their length according to the section variation seed, adding movement without making every transition equally dense.
- 12-bar sections receive shorter fills at bars 4 and 8, followed by the full-bar ending; 8-bar sections keep a half-bar midpoint fill and full-bar ending; 4-bar sections keep a quarter-bar midpoint fill and full-bar ending.
- Removed the obsolete global and per-section Fill Interval controls. Fill placement is now entirely phrase-driven.
- Kept Fill Repeat Control, section Intensity, Variation, drummer profiles, audio preview and the exact One-Bar Outro behavior.

## 0.3.16 – Phrase-Based Fill Schedule
- Replaced repeating every-N-bars fills with section-length-aware midpoint and ending fills across all genres.
- 16-bar sections: full-bar fills at bar 8 and bar 16.
- 8-bar sections: half-bar midpoint pickup and full-bar ending fill.
- 4–7-bar sections: quarter-bar midpoint pickup and full-bar ending fill.
- One-Bar Outro remains unchanged and protected.

# Changelog

## 0.5.0 — Hip-Hop Drum Solo
- Added a dedicated Hip-Hop Complete Solo engine with boom-bap backbeat, syncopated kick vocabulary, relaxed closed-hat pulse and low-velocity ghost snares.
- Added sparse rim/tom phrase punctuation instead of continuous rock-style tom runs.
- Preserved full final-bar continuity with no forced crash; Drum Break, Trading Fours and Solo Outro retain their separate behaviors.
- Updated Hip-Hop solo personality label and added regression tests.


## 0.4.2 – Blues Rock Shuffle Motif Solo
- Added a dedicated Blues Rock full-solo composer with a swung ride ostinato and recurring kick/snare motif.
- Added call-and-response tom phrases, restrained ghost notes, shuffle turnarounds and a decisive final cadence.
- Supports the existing 16- and 32-bar solo lengths; the same motif develops across longer forms.
- Classic Rock 0.4.1 behavior, other genre engines, audio assets and song-section integration remain unchanged.


## 0.3.15 – Advanced Fill Techniques & Alternative Rock Variation
- Added deterministic genre-aware Tom Runs, Snare Rolls with velocity crescendos, linear/alternating fills and triplet/shuffle phrases.
- Alternative Rock now has distinct Verse, Chorus and Bridge groove identities: the Verse is tighter and more restrained; the Chorus is wider, more driving and uses stronger cymbal lift.
- Alternative Rock fills rotate through four different rhythmic grammars to reduce repeated phrases.
- Existing fill intervals, full-bar section endings, One-Bar Outro, audio preview and GUI layout retained.

## 0.3.11 – GUI & Genre Selector Fix
- Fixed a missing closing brace in the generated UI script's full-bar fill loop.
- Restored JavaScript initialization, including the genre selector, section rendering, track/slot selectors, preview setup, and saved-settings restoration.
- Preserved 0.3.10 Full-Bar Fill Intelligence behavior.
- Added a regression check that extracts and syntax-checks the generated inline UI script.

# Changelog

## 0.5.0 — Hip-Hop Drum Solo
- Added a dedicated Hip-Hop Complete Solo engine with boom-bap backbeat, syncopated kick vocabulary, relaxed closed-hat pulse and low-velocity ghost snares.
- Added sparse rim/tom phrase punctuation instead of continuous rock-style tom runs.
- Preserved full final-bar continuity with no forced crash; Drum Break, Trading Fours and Solo Outro retain their separate behaviors.
- Updated Hip-Hop solo personality label and added regression tests.


## 0.4.2 – Blues Rock Shuffle Motif Solo
- Added a dedicated Blues Rock full-solo composer with a swung ride ostinato and recurring kick/snare motif.
- Added call-and-response tom phrases, restrained ghost notes, shuffle turnarounds and a decisive final cadence.
- Supports the existing 16- and 32-bar solo lengths; the same motif develops across longer forms.
- Classic Rock 0.4.1 behavior, other genre engines, audio assets and song-section integration remain unchanged.


## 0.3.5 – Solo Dramaturgy Engine
- Added a non-linear solo energy arc: restrained opening, progressive development, defined peak and a controlled release before the ending.
- Dynamic development now influences the arc's velocity and phrase density more musically, rather than relying on a simple linear rise.
- Full Solo receives a deliberate final snare/crash cadence within the final bar. Solo Outro's one-bar kick+crash ending remains unchanged.
- Existing genre personalities, drummer profiles, audio preview, persistent settings and arrangement generation retained.


## 0.3.2 – Audio Preview Sidebar
- Moved the complete Audio Preview controls (Preview, Stop and Preview Volume) into the far-left sidebar below the genre selector.
- Kept the preview status visible directly beneath the controls.
- Renumbered the main workflow: Create MIDI Clips is now section 4 and Drum Solo Engine is section 5.
- Audio engine, embedded MP3 assets, playback scheduling and native Preview Volume persistence are unchanged.
- Arrangement generation, genre-specific solo personalities and MIDI clip creation are unchanged.


## 0.3.3 — Persistent Settings
- Persist the complete relevant GUI state in Ableton's per-extension storage directory.
- Restore genre, arrangement controls, section-specific edits, drummer profile, groove controls, Solo Engine choices, target track/slot and Preview Volume when the extension is reopened.
- Save the state when the dialog is closed through Cancel, Create section clips or Create Drum Solo Clip.
- Keep the existing 0.3.2 GUI layout and musical engines unchanged.


## 0.3.4 – Solo Phrasing Intelligence
- Alternative Rock Full Solo now uses a phrase-led two-bar call/response structure with deliberate breathing bars, controlled tom answers and a clear cadence.
- Dynamic Development shapes phrase contrast and accent strength rather than continuously increasing note density.
- Solo generation receives the currently selected drummer profile; Offbeat Drive & Rimshots, Heavy Backbeat, rolling-tom and precision-fill profiles receive differentiated voicing.
- Bottom-left GUI label now displays the generated build label (BUILD 0.3.4), replacing the stale hard-coded version.
- Persistent settings, Audio Preview, arrangement engine and existing solo types retained.

## 0.3.6 – Genre-Aware Solo Engine
- Added dedicated solo vocabularies for Rock/Hard Rock, Blues Rock, Funk, Punk and Alternative Rock.
- Rock/Hard Rock emphasizes a firm backbeat and measured melodic tom runs.
- Blues Rock now has its own shuffle-inflected ride pulse, conversational snare phrasing and bluesy tom answers instead of the previous jazz/fusion proxy.
- Funk retains pocket-first syncopation and ghost-note articulation; Punk gets a more relentless eighth-note kick drive and explosive backbeat.
- Alternative Rock retains its motif-led two-bar call/response and breathing spaces.
- Preserved the 0.3.5 dramaturgy curve, drummer-style input, existing solo types, one-bar outro invariant and GUI layout.
- Updated the solo personality description to reflect the five target genre identities.


## 0.3.7 – Genre Expansion I (Rock)
- Expanded the Classic Rock / Hard Rock solo branch with distinct classic and heavier voicings driven by the selected drummer profile.
- Added a steadier rock cymbal time-bed, stronger hard-rock kick/snare accents, phrase-led crash punctuation, and profile-aware tom/snare endings.
- Kept the 0.3.5 dramaturgy curve, other genre profiles, GUI layout, persistent settings, Audio Preview, and exact One-Bar Outro behavior.

## 0.3.8 – Solo Interaction
- Added a two-bar call/response interaction layer for full solos: kick/snare/tom statements receive displaced tom/snare answers in the following bar.
- Eight-bar and longer solos recall the opening motif in bar five with thinner, altered voicing.
- Existing genre vocabularies, drummer profiles, dramaturgy, short solo types and the exact one-bar Solo Outro remain intact.
- GUI unchanged.

## 0.3.9 – Song Integration
- Added solo context selectors for the preceding and following song sections.
- Added section-aware solo pickups from Verse, Chorus, Bridge or Intro.
- Added destination-aware full-solo hand-offs into Chorus, Verse, Bridge or Outro.
- Preserved the existing solo dramaturgy, genre profiles, interaction layer, GUI layout outside the solo panel, and one-bar outro behavior.

## 0.3.9 – Song Integration
- Added previous-section and next-section choices to the Solo Engine.
- Solo pickup and Full Solo ending respond to the selected song-section context.
- Persisted both section-context controls with the existing UI settings.
- Preserved the standalone Session View MIDI clip workflow and One-Bar Outro invariant.

## 0.3.10 – Full-Bar Fill Intelligence
- Every scheduled fill and section-ending fill now replaces the complete 4/4 measure instead of occupying only the final half-bar.
- Fill measures no longer retain the normal groove, section embellishments or transition pickup; the full-bar phrase owns the measure.
- Added 32 deterministic rhythm/voicing combinations and song-wide fill-signature rotation to avoid repeated fill phrases within normal song lengths.
- Preserved section fill intervals, genre/drummer voicing, destination-aware section behavior outside fill measures, and the One-Bar Outro invariant.
- GUI layout unchanged.

## 0.3.13 – Fill Density & Fast Hands
- Fill vocabulary now mixes quarter/eighth-note anchors with additional sixteenth-note subdivisions.
- Punk and Rock favor faster fill density; Alternative Rock alternates sparse and busy phrases.
- Fill instrument movement is more active, with deterministic kick/snare/tom alternation.
- Sparse variants remain available to preserve contrast and musical breathing room.
- Full-bar fill replacement, song-wide signature rotation, GUI and existing arrangement behavior retained.

## 0.3.14 – Fill Structure & Punk Dynamics
- Intermediate fill interval events now use alternating quarter-bar and half-bar pickups; only the final bar of each section receives a full-bar fill.
- Fill windows replace the underlying groove notes rather than stacking on top of them.
- Punk fills use denser 16th-grid orchestration with faster snare/tom/kick changes and varied sparse/dense phrases.
- Rock and Alternative Rock alternate restrained eighth-note and faster sixteenth-note figures.
- Section-end fills retain the full-bar cadence role.

## Version 0.4.3 – Alternative Rock Broken Motif Solo
Alternative Rock full solos now use a dedicated broken-backbeat motif, deliberate quiet-to-loud dynamic drops, syncopated kick/snare answers, four phrase-ending fill shapes and flam accents. Flams are encoded as a soft grace note immediately before a stronger main stroke. The 16- and 32-bar forms build toward a shared kick/snare/crash ending. Classic Rock 0.4.1 and Blues Rock 0.4.2 solo composers remain separate and unchanged.


## 0.4.4
- Added a dedicated Punk Raw Energy full-solo engine for 16- and 32-bar solos.
- Added motif-led phrase development, kick/snare drive, short snare bursts, tom fills, flam accents and stop-and-go breaks.
- Preserved the existing Classic Rock, Blues Rock and Alternative Rock solo branches and audio assets.


## 0.4.5 – Reggae Drum Solo
- Added a dedicated 16-/32-bar Reggae full-solo engine with a One Drop foundation, Rockers development, Steppers peak and a clear final ensemble hit.
- Added Rockers and Steppers drummer profiles alongside One Drop and Tight Reggae.
- Preserved the existing Classic Rock, Blues Rock, Alternative Rock and Punk solo engines.

## 0.4.8 — Ska Drum Solo
- Added a dedicated Ska Complete Solo engine with persistent offbeat eighth-note lift, ska backbeat, syncopated kick variations and melodic tom/snare call-and-response.
- Maintains a full final bar without a forced crash outro; Solo Outro remains the separate ending mode.
- Added regression tests for 8/16/32-bar continuity, offbeat identity, phrase development and deterministic variation.

## 0.4.9 — Funk Drum Solo
- Added a dedicated Funk solo phrase grammar: syncopated kick, quiet snare ghosts, dynamic sixteenth-note hi-hat, rim accents and tom call-and-response.
- Four-bar phrasing develops from pocket establishment through tom answers to a more linear peak phrase.
- Complete Solo continues through the final bar without a forced crash or artificial break.
- Added regression coverage for 8/16/32-bar arrangements and deterministic seed variation.
