# Copyright and credits

Copyright © 2026 Hans-Georg Tröster (HGT). All rights reserved, subject to the accompanying project license and applicable third-party license terms.

Concept, musical requirements, GUI planning and testing: Hans-Georg Tröster (HGT).

Software development and technical implementation created with assistance from ChatGPT, an AI assistant by OpenAI.

This is an independent third-party extension for Ableton Live. Ableton and Ableton Live are names and/or trademarks of their respective owner. No affiliation with or endorsement by Ableton AG is implied.
